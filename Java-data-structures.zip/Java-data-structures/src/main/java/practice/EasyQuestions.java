package practice;

import core.enumExamples.A;

import java.lang.reflect.Array;
import java.util.*;

public class EasyQuestions {
    public static void main(String[] args) {
//        swapWithoutThirdVar(2,3);

//        int[] arr = {1, 2, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 16};
////        System.out.println(missingNumberForOne(arr,9));
//        missingNumberForMultiple(arr, 16);


        int[][] test = new int[][]{
                {1, 1, 2, 2, 3, 4, 5},
                {1, 1, 1, 1, 1, 1, 1},
                {1, 2, 3, 4, 5, 6, 7},
                {1, 2, 1, 1, 1, 1, 1}};

        for (int[] input : test) {
            System.out.println("Array with Duplicates       : " + Arrays.toString(input));
            System.out.println("After removing duplicates   : " + duplicates2(input));
        }
//        int[] arr = {1, 3, 4, 5, 9, 12, 45, 23, 11, 13, 2};
//        largestAndSmallest(arr);
    }

    public static void swapWithoutThirdVar(int x, int y) {
        System.out.println("X - " + x + " & " + "Y - " + y);

        x = x + y;
        y = x - y;
        x = x - y;

        System.out.println("X - " + x + " & " + "Y - " + y);
    }

    public static int missingNumberForOne(int[] numbers, int totalCount) {
        int expectedOutput = totalCount * ((totalCount + 1) / 2);
        int output = 0;
        for (int i : numbers) {
            output += i;
        }

        return expectedOutput - output;
    }

    public static void missingNumberForMultiple(int[] numbers, int totalCount) {
        int missingCount = totalCount - numbers.length;
        BitSet bitSet = new BitSet(totalCount);

        for (int number : numbers) {
            bitSet.set(number - 1);
        }

        System.out.printf("Missing numbers in array %s, with total number of count %d %n is ", Arrays.toString(numbers), totalCount);
        System.out.println();
        int lastMissingIndex = 0;
        for (int i = 0; i < missingCount; i++) {
            lastMissingIndex = bitSet.nextClearBit(lastMissingIndex);
            System.out.println(++lastMissingIndex);
        }
    }

    public static int[] removeDuplicates(int[] numbersWithDuplicates) {
        Arrays.sort(numbersWithDuplicates);

        int[] result = new int[numbersWithDuplicates.length];

        int previous = numbersWithDuplicates[0];
        result[0] = previous;

        for (int i = 1; i < numbersWithDuplicates.length; i++) {
            int ch = numbersWithDuplicates[i];
            if (previous != ch) {
                result[i] = ch;
            }
            previous = ch;
        }

        return result;
    }

    public static void largestAndSmallest(int[] numbers) {
        int largest = 0;
        int smallest = Integer.MAX_VALUE;
        for (int number : numbers) {
            if (number > largest) {
                largest = number;
            } else if (number < smallest) {
                smallest = number;
            }
        }

        System.out.println("Largest: " + largest + "\n" + "Smallest: " + smallest);
    }

    //O(nlogn) time and O(n) space
    public static int[] duplicates(int[] arr) {
        Arrays.sort(arr);
        int[] result = new int[arr.length];
        int previous = arr[0];
        result[0] = previous;

        for (int i=1;i<arr.length;i++){
            int ch = arr[i];
            if(previous != ch) {
                result[i] = ch;
            }
            previous = ch;
        }

        return result;
    }

    public static List<Integer> duplicates2(int[] arr) {
        ArrayList<Integer> list = new ArrayList<>();
        for (int a :arr) {
            list.add(a);
        }
        Set<Integer> ans = new TreeSet<>(list);
        return new ArrayList<>(ans);
    }

}
