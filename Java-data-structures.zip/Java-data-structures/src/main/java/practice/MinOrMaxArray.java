package practice;

import core.enumExamples.A;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MinOrMaxArray {
    public static void main(String[] args) {
//        Integer[] arr = {2,4,5,2,4,9};
//        System.out.println(maxElement(arr));
//        System.out.println(minElement(arr));

        List<Integer> list = new ArrayList<>() {{
            add(5);
            add(7);
            add(9);
            add(1);
            add(2);
        }};

        System.out.println(secondLargest(list));

        String str = "Hello World Hello";
        repeatedWords(str);

    }

    public static int maxElement(Integer[] arr) {
        return Arrays.stream(arr).max(Integer::compare).get();
    }

    public static int minElement(Integer[] arr) {
        return Arrays.stream(arr).min(Integer::compare).get();
    }

    public static int secondLargest(List<Integer> list) {


        List<Integer> answer = list.stream().sorted(Comparator.reverseOrder()).filter(n -> n % 2 != 0).skip(1).collect(Collectors.toList());

        return answer.get(0);
    }

    public static void repeatedWords(String str) {
        Map<String, Long> map = Arrays.asList(str.split(" ")).stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(map);

    }


}
