package practice;

import java.util.HashSet;
import java.util.OptionalInt;
import java.util.Set;

public class PracticeSession2 {
    public static void main(String[] args) {
//        System.out.println(factRec(5));
//        System.out.println(isLeapYear(2000));
//        fibonacci(6);
//        fibonacci2(6);
//        System.out.println(isPalindrome(123));
//        System.out.println(replaceString("i like this program very much"));
        System.out.println(firstRepeatedCharacter("my name is aditya"));
    }

    public static int factorial(int n) {
        // 4! = 4 * 3 * 2 * 1

        int fact = 1;

        for (int i = n; i >= 1; i--) {
            fact *= i;
        }

        return fact;

    }

    public static int factRec(int n) {
        if (n == 1) {
            return 1;
        }

        return n * factRec(n - 1);
    }

    public static boolean isLeapYear(int year) {
        return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    }

    public static void fibonacci(int n) {
        int a = 0;
        int b = 1;
        int c = 0;

        System.out.print(a + " " + b);

        for (int i = 0; i<n; i++) {
            c = a + b;
            System.out.print(" " + c);
            a = b;
            b = c;
        }

    }

    public static int fibonacci2(int n) {
        if(n == 0 || n == 1)
            return 1;
        return fibonacci2(n-1)+ fibonacci2(n-2);
    }

    public static boolean isPalindrome(int n) {
        int reverse = 0;
        int temp = n;

        while(n > 0) {
            int digit = n % 10;
            reverse = reverse * 10 + digit;
            n /= 10;
        }
        return temp == reverse;
    }

    public static String replaceString(String s) {
        s = s.replace(" ", "%@");
        return s;
    }

    public static char firstRepeatedCharacter(String s) {
        Set<Integer> seen = new HashSet<>();
        OptionalInt first = s.chars()
                .filter(i -> !seen.add(i))
                .findFirst();
        return first.isPresent() ? (char) first.getAsInt() : null;
    }



}
