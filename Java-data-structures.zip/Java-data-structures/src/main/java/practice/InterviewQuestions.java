package practice;

import java.util.*;

public class InterviewQuestions {
    public static void main(String[] args) {

//        System.out.println(maxOccurChar("java"));
//        removeDuplicates("Aaabbbccc");

//        duplicateWords("This sentence contains two words, one and two");

//        printDuplicates("Aaaaaabaaaacccc");

        removeChars("india is great", "in");
    }

    // 1. How to find the maximum occurring character in a given String?
    public static char maxOccurChar(String str) {
        Map<Character, Integer> map = new HashMap<>();
        for (char c: str.toCharArray()) {
            if(map.containsKey(c)) {
                map.put(c, map.get(c) + 1);
            }else {
                map.put(c, 1);
            }
        }

        return Collections.max(map.entrySet(), Map.Entry.comparingByValue()).getKey();

    }

    // 2.  How to remove all duplicates from a given string?
    public static void removeDuplicates(String str) {
        Set<Character> set = new HashSet<>();
        StringBuilder sb = new StringBuilder();

        for (char c :str.toCharArray()) {
            set.add(c);
        }

        for (Character c : set) {
            sb.append(c);
        }

        System.out.println(sb);

    }

    // 3. How to print the duplicate characters from the given String?
    public static void duplicateWords(String input) {
        if(input == null || input.isEmpty()) {
            System.out.println("String is null of empty.");
            return;
        }

        Set<String> duplicates = new HashSet<>();
        String[] words = input.split("\\s+");

        Set<String> set = new HashSet<>();

        for (String word: words) {
            if(!set.add(word)) {
                duplicates.add(word);
            }
        }
        System.out.println(duplicates);

    }

    // 4. How to print the duplicate characters from the given String?
    public static void printDuplicates(String s) {
        Map<Character, Integer> map = new HashMap<>();
        for (char c : s.toCharArray()) {
            if(map.containsKey(c)) {
                map.put(c, map.get(c) + 1);
            }else{
                map.put(c, 1);
            }
        }

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.print(entry.getKey() + " ");
            }
        }
    }

    // 5. How to remove characters from the first String which are present in the second String?
    public static void removeChars(String s1, String s2) {
        StringBuilder sb = new StringBuilder();
        Set<Character> set = new HashSet<>();

        for (Character c: s2.toCharArray()) {
            set.add(c);
        }

        for (char c: s1.toCharArray()) {
            if (!set.contains(c)) {
                sb.append(c);
            }
        }

        System.out.println(sb);

    }


}
