package practice;

import core.enumExamples.A;

import java.util.*;
import java.util.stream.Collectors;

public class PracticeSession {
    public static void main(String[] args) {
//        String s = "sky";
//        System.out.println(isVowelPresent(s));
//
//        Integer[] arr = {4, 2, 8, 1, 9};
//        int[] arr2 = {1, 2, 3, 4, 5};
//        System.out.println(checkTwoArrays(arr1, arr2));

//        System.out.println(removeSpace("Ad i t y a"));
//        System.out.println(kthLargestElement(arr, 2));

//        showNullPE();
//        String s = "I love my India";
//        System.out.println(reverseString(s));

//        String[] arr = {"club", "clue", "clutch", "circle", "club", "clumsy"};
//        System.out.println(longestCommonPrefix(arr));
//        System.out.println(longestCommonPrefix2(arr));

//        String[] arr = {"the", "quick", "brown", "fox", "quick"};
//
//        System.out.println(shortestDistWords(arr, "the", "fox"));

//        System.out.println(isDivisibleBy7(22));
//        System.out.println(isDivisibleBySeven(21));
//        System.out.println(factorialRec(5));
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i <= 10; i++) {
            list.add(i);
        }

        System.out.println(evenNumbers(list));


    }

    // If vowel is present
    public static boolean isVowelPresent(String s) {
        return s.toLowerCase().matches(".*[aeiou].*");
    }

    public static boolean checkTwoArrays(int[] arr1, int[] arr2) {
        return Arrays.equals(arr1, arr2);
    }

    public static String removeSpace(String s) {
        s = s.replace(" ", "");
        return s;
    }

    public static int kthLargestElement(Integer[] arr, int k) {
        List<Integer> list = Arrays.stream(arr).sorted(Collections.reverseOrder()).skip(k - 1).toList();
        return list.get(0);
    }

    public static void showNullPE() {
        String s = null;

        try {
            if (s.equals("gfg")) {
                System.out.println("yes");
            } else {
                System.out.println("No");
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    public static StringBuilder reverseString(String s) {
        StringBuilder reverse = new StringBuilder();

        String[] sArr = s.split(" ");

        for (int i = sArr.length - 1; i >= 0; i--) {
            reverse.append(sArr[i]);
            if (i != 0) {
                reverse.append(" ");
            }
        }

        return reverse;
    }

    public static StringBuilder longestCommonPrefix(String[] arr) {
        StringBuilder prefix = new StringBuilder();
        int indexNumber = 0;
        int lengthOfString = 0;
        // to find the min length and the smallest String
        for (int i = 1; i < arr.length; i++) {
            lengthOfString = Math.min(arr[i - 1].length(), arr[i].length());
            if (i == arr.length - 1) {
                if (arr[i - 1].length() < arr[i].length()) {
                    indexNumber = i - 1;
                } else {
                    indexNumber = i;
                }
            }
        }

        for (int i = 0; i < lengthOfString; i++) {
            char ch = arr[indexNumber].charAt(i);
            boolean isPresent = false;
            for (String s : arr) {
                if (s.charAt(i) == ch) {
                    isPresent = true;
                } else {
                    isPresent = false;
                    break;
                }
            }
            if (isPresent) {
                prefix.append(ch);
            }
        }

        return prefix;
    }


    //Optimized solution - Time: O(nlogn), (sorting -> quick sort -> fastest -> nlogn) Space: O(1)
    public static StringBuilder longestCommonPrefix2(String[] arr) {
        Arrays.sort(arr);
        StringBuilder prefix = new StringBuilder();
        String first = arr[0];
        String last = arr[arr.length - 1];
        for (int i = 0; i < first.length(); i++) {
            if (first.charAt(i) == last.charAt(i)) {
                prefix.append(first.charAt(i));
            } else {
                break;
            }
        }

        return prefix;
    }

    public static int shortestDistWords(String[] arr, String word1, String word2) {
        int count = 0;
        int index = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(word1)) {
                index = i;
                break;
            }
        }

        for (int i = index; i < arr.length; i++) {
            if (arr[i].equals(word2)) {
                break;
            }
            count++;
        }

        return count;
    }

    public static boolean isDivisibleBy7(int num) {
        boolean yes = false;
        while (num > 0) {
            num -= 7;
            if (num < 7) {
                break;
            } else if (num == 7) {
                yes = true;
                break;
            }
        }

        return yes;
    }

    public static boolean isDivisibleBySeven(int num) {
        if (num < 0)
            isDivisibleBySeven(-num);

        if (num == 0 || num == 7)
            return true;

        if (num < 10)
            return false;

        return isDivisibleBySeven(num / 10 - 2 * (num - num / 10 * 10));
    }

    public static String encryptString(String s) {
        StringBuilder ans = new StringBuilder();

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            int count = 0;
            String hex;

            while (i < s.length() && s.charAt(i) == ch) {
                count++;
                i++;
            }

            i--;

            hex = convertToHex(count);

            ans.append(hex);

        }

        ans.reverse();

        return ans.toString();
    }

    private static String convertToHex(int num) {
        StringBuilder temp = new StringBuilder();
        while (num != 0) {
            int rem = num % 16;
            char c;
            if (rem < 10) {
                c = (char) (rem + 48);
            } else {
                c = (char) (rem + 87);
            }

            temp.append(c);
            num = num / 16;
        }

        return temp.toString();
    }

    public static int factorialRec(int n) {
        // Base check
        if (n == 1) {
            return 1;
        }
        return n * factorialRec(n - 1);
    }


    public static List<Integer> evenNumbers(List<Integer> list) {
        return list.stream().filter(n -> n % 2 == 0).toList();
    }

}
