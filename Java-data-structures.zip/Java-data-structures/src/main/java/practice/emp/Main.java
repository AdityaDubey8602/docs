package practice.emp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        // Convert List<Employee> into Map<EmployeeCity, List<Employee>>
        List<Employee> employees = createList();

        Map<String, List<Employee>> emplMap = employees.stream().collect(Collectors.groupingBy(Employee::getEmpCity));

        emplMap.forEach((key, value) -> System.out.println("City: " + key + "\nValue: " + value));

    }

    public static List<Employee> createList() {
        Employee e1 = new Employee(1, "Aditya", "Rajgarh");
        Employee e2 = new Employee(2, "Anshul", "Chittorh");
        Employee e3 = new Employee(3, "Ananya", "Rajgarh");
        Employee e4 = new Employee(4, "Shreya", "Bina");
        Employee e5 = new Employee(5, "Akshita", "Ujjain");

        List<Employee> employees = new ArrayList<>();
        employees.add(e1);
        employees.add(e2);
        employees.add(e3);
        employees.add(e4);
        employees.add(e5);

        return employees;
    }
}
