package practice.emp;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Java8Questions {
    public static void main(String[] args) {

//        List<Integer> list = Arrays.asList(71, 18, 42, 21, 67, 32, 95, 14, 56, 87);
//        separateOddEven(list);
//        removeDuplicate(strings);
//        List<String> strings = Arrays.asList("Java", "Python", "C#", "Java", "Kotlin", "Python");
//        findFrequency(strings);
//        String inputString = "Java Concept Of The Day";
//        findFrequency2(inputString);
//        List<Double> list = Arrays.asList(12.45, 23.58, 17.13, 42.89, 33.78, 71.85, 56.98, 21.12);
//        sortDecimalReverse(list);
//        List<String> words = Arrays.asList("Facebook", "Twitter", "YouTube", "WhatsApp", "LinkedIn");
//        join(words);
//        List<Integer> list = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);
//        printMuliplesOf5(list);
//        List<Integer> list = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);
//        maxAndMin(list);
//        int[] arr1 = new int[] {4, 2, 7, 1};
//        int[] arr2 = new int[] {8, 3, 9, 5};
//        merge(arr1,arr2);
//        int[] arr1 = new int[]{4, 2, 5, 1};
//        int[] arr2 = new int[]{8, 1, 9, 5};
//        mergeWithoutDuplicates(arr1, arr2);
//
//
//        List<Integer> list = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);
//        maxAndMinThree(list);

//        anagramCheck("Racecar", "CarRace");

//        System.out.println(sumOfDigits(1234));
//        Integer[] arr = {45, 12, 56, 15, 24, 75, 31, 89};
//        System.out.println(secondLargest(arr));

//        List<String> list = Arrays.asList("Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C");
//        sortListLength(list);

//        int[] arr = new int[] {45, 12, 56, 15, 24, 75, 31, 89};
//        sumAndAverage(arr);

//        List<Integer> list1 = Arrays.asList(71, 21, 34, 89, 56, 28);
//        List<Integer> list2 = Arrays.asList(12, 56, 17, 21, 94, 34);
//
//        commonElementsArrays(list1, list2);

//        reverse("Java Concept Of The Day");

//        sum10NaturalNum();

//        int[] arr = new int[]{5, 1, 7, 3, 9, 6};
//        reverseArray(arr);

//        printEven();

//        String[] arr = new String[] {"Pen", "Eraser", "Note Book", "Pen", "Pencil", "Pen", "Note Book", "Pencil"};
//        mostRepeated(arr);

//        Integer[] arr = {1,1,1,3,3,3,4,5,5,5,5,5,5};
//        mostRepeatedInt(arr);

//        System.out.println(pow(2, 2));
//        solve();
        firstRepeated();

    }


    // 1. Given a list of integers, separate odd and even numbers?
    public static void separateOddEven(List<Integer> listOfIntegers) {
        Map<Boolean, List<Integer>> ans = listOfIntegers.stream().collect(Collectors.partitioningBy(i -> i % 2 == 0));
        Set<Map.Entry<Boolean, List<Integer>>> entrySet = ans.entrySet();

        for (Map.Entry<Boolean, List<Integer>> entry : entrySet) {
            System.out.println("----------------------");
            if (entry.getKey()) {
                System.out.println("Even Numbers: ");
            } else {
                System.out.println("Odd Numbers: ");
            }
            System.out.println("----------------------");
            List<Integer> list1 = entry.getValue();
            for (Integer n : list1) {
                System.out.print(n + " ");
            }
            System.out.println();
        }
    }

    // 2. How do you remove duplicate elements from a list using Java 8 streams?
    public static void removeDuplicate(List<String> list) {
        List<String> uniqueStrings = list.stream().distinct().toList();
        System.out.println(uniqueStrings);
    }

    // 3. How do you find frequency of each character in a string using Java 8 streams?
    // a) for word
    public static void findFrequency(List<String> list) {

        Map<String, Long> wordCountMap = list.stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(wordCountMap);
    }

    // b) for each character
    public static void findFrequency2(String words) {

        Map<Character, Long> charMap = words.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(charMap);
    }

    // 4. How do you sort the given list of decimals in reverse order?
    public static void sortDecimalReverse(List<Double> list) {
        List<Double> ans = list.stream().sorted(Comparator.reverseOrder()).toList();
        System.out.println(ans);
    }

    // 5. Given a list of strings, join the strings with ‘[‘ as prefix, ‘]’ as suffix and ‘,’ as delimiter?
    public static void join(List<String> list) {
        String joinedString = list.stream().collect(Collectors.joining(",", "[", "]"));
        System.out.println(joinedString);
    }

    // 6. From the given list of integers, print the numbers which are multiples of 5?
    public static void printMuliplesOf5(List<Integer> list) {
        List<Integer> ans = list.stream().filter(n -> n % 5 == 0).toList();
        System.out.println(ans);
    }

    // 7. Given a list of integers, find maximum and minimum of those numbers?
    public static void maxAndMin(List<Integer> list) {
        int max = list.stream().max(Comparator.naturalOrder()).get();
        int min = list.stream().min(Comparator.naturalOrder()).get();
        System.out.printf("Maximum num: %d and Minimum number is %d", max, min);
    }

    // 8. How do you merge two unsorted arrays into single sorted array using Java 8 streams?
    public static void merge(int[] arr1, int[] arr2) {
        int[] sortedMergedArray = IntStream.concat(Arrays.stream(arr1), Arrays.stream(arr2)).sorted().toArray();
        System.out.println(Arrays.toString(sortedMergedArray));
    }

    // 9. How do you merge two unsorted arrays into single sorted array without duplicates?
    public static void mergeWithoutDuplicates(int[] arr1, int[] arr2) {
        int[] sortedArray = IntStream.concat(Arrays.stream(arr1), Arrays.stream(arr2)).sorted().distinct().toArray();
        System.out.println(Arrays.toString(sortedArray));
    }

    // 10. How do you get three maximum numbers and three minimum numbers from the given list of integers?
    public static void maxAndMinThree(List<Integer> list) {
        System.out.println("Minimum 3 Numbers: ");
        list.stream().sorted().limit(3).forEach(x -> System.out.print(x + " "));
        System.out.println();
        System.out.println("Maximum 3 Numbers: ");
        list.stream().sorted(Comparator.reverseOrder()).limit(3).forEach(x -> System.out.print(x + " "));
    }

    // 11. Java 8 program to check if two strings are anagrams or not?
    public static void anagramCheck(String s1, String s2) {

//        s1 = s1.trim();
//        s2 = s2.trim();
//
//        char[] arr1 = s1.toCharArray();
//        char[] arr2 = s2.toCharArray();
//
//        Arrays.sort(arr1);
//        Arrays.sort(arr2);
//
//        String st1 = "";
//        String st2 = "";
//
//
//        for (char c: arr1) {
//            st1 += c;
//        }
//
//        for (char c: arr2) {
//            st2 += c;
//        }
//
//        if(st1.equalsIgnoreCase(st2)) {
//            System.out.println("Are anagrams");
//        }else {
//            System.out.println("Not anagrams");
//        }

        s1 = Stream.of(s1.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
        s2 = Stream.of(s2.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());

        if (s1.equalsIgnoreCase(s2)) {
            System.out.println("Are anagrams");
        } else {
            System.out.println("Not Anagrams");
        }
    }

    // 12. Find sum of all digits of a number in Java 8?
    public static Integer sumOfDigits(int num) {

//        int len = (int) Math.log10(num) + 1;
//        int sum = 0;
//
//        for (int i = 0; i<len; i++) {
//            sum += num % 10;
//            num /= 10;
//        }

        return Stream.of(String.valueOf(num).split("")).collect(Collectors.summingInt(Integer::parseInt));
    }


    // 13. Find second-largest number in an integer array?
    public static int secondLargest(Integer[] arr) {
        List<Integer> integers = Arrays.asList(arr);

        return integers.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
    }

    // 14.  Given a list of strings, sort them according to increasing order of their length?
    public static void sortListLength(List<String> strings) {
        strings.stream().sorted(Comparator.comparing(String::length)).forEach(x -> System.out.print(x + " "));
    }

    // 15. Given an integer array, find sum and average of all elements?
    public static void sumAndAverage(int[] arr) {
        int sum = Arrays.stream(arr).sum();
        System.out.println("Sum is: " + sum);

        double avg = Arrays.stream(arr).average().getAsDouble();
        System.out.println("Average is: " + avg);
    }

    // 16. How do you find common elements between two arrays?
    public static void commonElementsArrays(List<Integer> list1, List<Integer> list2) {
        list1.stream().filter(list2::contains).forEach(x -> System.out.print(x + " "));
    }

    // 17. Reverse each word of a string using Java 8 streams?
    public static void reverse(String str) {
        String reversedString = Arrays.stream(str.split(" "))
                .map(s -> new StringBuffer(s).reverse())
                .collect(Collectors.joining(" "));
        System.out.println(reversedString);
    }

    // 18. How do you find sum of first 10 natural numbers?
    public static void sum10NaturalNum() {
        int sum = IntStream.range(1, 11).sum();
        System.out.println(sum);
    }

    // 19. Reverse an integer array
    public static void reverseArray(int[] arr) {
        int[] reversedArray = IntStream.rangeClosed(1, arr.length).map(i -> arr[arr.length - i]).toArray();
        System.out.println(Arrays.toString(reversedArray));
    }

    // 20. Print first 10 even numbers
    public static void printEven() {
        IntStream.rangeClosed(1, 10).map(i -> i * 2).forEach(x -> System.out.print(x + " "));
    }

    // 21. How do you find the most repeated element in an array?
    public static void mostRepeated(String[] arr) {
        List<String> list = Arrays.asList(arr);
        Map<String, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        Map.Entry<String, Long> mostFrequentElement = map.entrySet().stream().max(Map.Entry.comparingByValue()).get();
        System.out.print(mostFrequentElement.getKey() + " : " + mostFrequentElement.getValue());

    }

    public static void mostRepeatedInt(Integer[] arr) {

        List<Integer> list = Arrays.asList(arr);
        Map<Integer, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        Map.Entry<Integer, Long> mostFrequentElement = map.entrySet().stream().max(Map.Entry.comparingByValue()).get();
        System.out.println(mostFrequentElement.getKey());

    }

    public static double pow(double base, int exponent) {
        double result = 1;

        if (exponent < 0)
            return 1;

        while (exponent > 0) {
            result *= base;
            exponent--;
        }

        return result;
    }

    // Using streams please solve :
    // input: ("abc.def.ghi", "pqr.mno.stu") output: (abc,def,ghi,pqr,mno,stu)
    public static void solve() {
        List<String> list = Arrays.asList("abc.def.ghi", "pqr.mno.stu");

        String s = list.stream().flatMap(x -> Arrays.stream(x.split("\\."))).collect(Collectors.joining(","));

        System.out.println(s);
    }

    public static void firstRepeated() {
        String str = "my name is aditya";
        Map<Character, Integer> map = new LinkedHashMap<>();

        str = str.replace(" ", "");

        for (int i = 0; i < str.length(); i++) {
            if (map.containsKey(str.charAt(i))) {
                map.put(str.charAt(i), map.get(str.charAt(i)) + 1);
            } else {
                map.put(str.charAt(i), 1);
            }
        }

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey());
                break;
            }
        }


//        String input = "my name is aditya";
//        Set<Integer> seen = new HashSet<>();
//        OptionalInt first = input.chars()
//                .filter(i -> !seen.add(i))
//                .findFirst();
//        if (first.isPresent()) {
//            System.out.println((char) first.getAsInt());
//        }

    }


}
