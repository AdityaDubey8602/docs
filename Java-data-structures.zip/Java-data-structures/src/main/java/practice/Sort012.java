package practice;

import java.util.Arrays;

public class Sort012 {
    public static void main(String[] args) {
        int[] arr = {0, 1, 2, 0, 1, 2};
        sort(arr);
        mySort(arr);
        DNF(arr);
    }

    public static void sort(int[] arr) {
        arr = Arrays.stream(arr).sorted().toArray();
        System.out.println(Arrays.toString(arr));
    }


    public static void mySort(int[] arr) {
        boolean swapped;
        for (int i = 0; i < arr.length; i++) {
            swapped = false;
            for (int j = 1; j < arr.length; j++) {
                if (arr[j] < arr[j - 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j - 1];
                    arr[j - 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.out.println(Arrays.toString(arr));
    }


    // Dutch National Flag problem
    public static void DNF(int[] arr) {

        int start = 0;
        int mid = 0;

        int pivot = 1;

        int end = arr.length - 1;

        while (mid <= end) {

            if (arr[mid] < pivot) {
                swap(arr, start, mid);
                ++mid;
                ++start;
            } else if (arr[mid] > pivot) {
                swap(arr, mid, end);
                --end;
            } else {
                ++mid;
            }
        }

        System.out.println(Arrays.toString(arr));
    }

    public static void swap(int[] arr, int start, int end) {
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
    }

}
