package practice;

import java.util.Arrays;

public class SortTheArray {

    public static void main(String[] args) {
        int[] arr = {7, 4, 8, 0, 2};
        bubble(arr);
        selection(arr);
    }

    public static void bubble(int[] arr) {

        boolean swapped;

        for (int i = 0; i < arr.length; i++) {
            swapped = false;
            for (int j = 1; j < arr.length; j++) {
                if (arr[j] < arr[j - 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j - 1];
                    arr[j - 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) {
                break;
            }
        }

        System.out.println(Arrays.toString(arr));
    }

    public static void selection(int[] arr) {

        for (int i = 0; i < arr.length; i++) {
            int last = arr.length - i - 1;
            int maxIndex = getMaxIndex(arr, 0, last);

            swap(arr, maxIndex, last);
        }

        System.out.println(Arrays.toString(arr));
    }

    public static int getMaxIndex(int[] arr, int start, int end) {
        int max = start;

        for (int i = 0; i <= end; i++) {
            if (arr[max] < arr[i]) {
                max = i;
            }
        }

        return max;
    }

    private static void swap(int[] arr, int first, int last) {
        int temp = arr[first];
        arr[first] = arr[last];
        arr[last] = temp;
    }

}
