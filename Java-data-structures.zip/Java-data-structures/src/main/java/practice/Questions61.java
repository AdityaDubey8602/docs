package practice;

import java.util.*;

public class Questions61 {
    public static void main(String[] args) {
//        displayEven();
//        factorial(100);
//        System.out.println(leapYear(2001));
//        fibonacciIterative(10);
//        fibonacciRecursive(10);

//        System.out.println(isPalindromeUsingString("naman"));
//        System.out.println(isPalindromeUsingInteger(1213121));
//        prime(2, 10);
//        printPyramid(5);
//        printReversePyramid(5);

//        areaAndParameterOfCircle(2);

//        triangle2(5);

//        System.out.println(factorialRec(5));

//        readFloatTypeNum(12.5f);

//        int[] arr = {1,5,6,7,2,0};
//        System.out.println(randomNumber(arr));

//        String s = "I am Aditya Dubey";
//        replaceSpace(s);

//        int[] arr1 = {1,2,3,4,5};
//        int[] arr2 = {6,7,8,9,10};

//        System.out.println(Arrays.toString(mergeArrays(arr1,arr2,arr1.length, arr2.length)));
//        mergeTwoArrays(arr1,arr2);

        String s1 = "Aditya   ";
        String s2 = "aytida";

        System.out.println(anagramCheck(s1,s2));


    }

    // 1. Write a program to display the list of even numbers.
    public static void displayEven() {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i <= 20; i++) {
            list.add(i);
        }

        list.stream().filter(n -> n % 2 == 0).forEach(System.out::println);
    }

    // 2. Find the Factorial of a given number.
    public static void factorial(int num) {
        int factorial = 1;
        while (num > 0) {
            factorial *= num;
            num -= 1;
        }
        System.out.println(factorial);
    }

    // 3. Write a program to determine If the given year is a Leap year.
    public static boolean leapYear(int year) {
        return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    }

    // 4. Print all the elements in the Fibonacci number series.This program can be implemented using a loop or recursion technique.
    public static void fibonacciIterative(int num) {
        int a = 0, b = 1, c;
        System.out.print(a + " " + b + " ");
        for (int i = 2; i < num; ++i) {
            c = a + b;
            System.out.print(c + " ");
            a = b;
            b = c;
        }
    }

    static int a = 0, b = 1, c = 0;

    public static void fibonacciRecursive(int num) {
        if (a == 0) {
            System.out.println();
            System.out.print(a);
        }

        if (num > 0) {
            c = a + b;
            a = b;
            b = c;

            System.out.print(" " + c);
            fibonacciRecursive(num - 1);
        }
    }

    // 5. Write a program to check if the number is Palindrome number or not.
    public static boolean isPalindromeUsingString(String str) {
        StringBuilder s1 = new StringBuilder();
        for (int i = str.length() - 1; i >= 0; i--) {
            s1.append(str.charAt(i));
        }

        return str.contentEquals(s1);
    }

    public static boolean isPalindromeUsingInteger(int num) {
        int temp = num;
        int rev = 0;

        while (temp > 0) {
            int digit = temp % 10;
            rev = rev * 10 + digit;
            temp /= 10;
        }

        return num == rev;
    }

    // 6. Generate all the prime numbers between one & the given number.
    public static void prime(int lower, int upper) {
        for (int i = lower; i < upper + 1; i++) {
            int counter = 0;
            for (int j = 1; j <= i; j++) {
                if (i % j == 0) {
                    counter++;
                }
            }
            if (counter == 2)
                System.out.println(i + " ");
        }
    }

    // 7. Print the Pyramid of stars using nested for loops.
    public static void printPyramid(int n) {
        int k = n - 1;
        for (int row = 0; row < n; row++) {
            for (int j = 0; j < k; j++) {
                System.out.print(" ");
            }
            k = k - 1;
            for (int j = 0; j < row + 1; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }

    // 8. Print Reversed pyramid on programming console using for loops & decrement operator.
    public static void printReversePyramid(int row) {

        for (int i = row; i >= 0; i--) {
            for (int j = 0; j < row - i; j++) {
                System.out.print(" ");
            }

            for (int j = 0; j < 2 * i - 1; j++) {
                System.out.print("*");
            }

            System.out.println();
        }

    }

    // 9. Write a program to calculate Circle Area and Perimeter using radius.
    public static void areaAndParameterOfCircle(int radius) {
        double area = Math.PI * radius * radius;
        double parameter = 2 * Math.PI * radius;

        System.out.println("Area: " + area + " & Parameter: " + parameter);
    }

    // 10. Find the Factorial of a number using recursion technique.
    public static int factorialRec(int num) {
        if (num == 0)
            return 1;
        if (num == 1)
            return num;

        return num * factorialRec(num - 1);
    }

    // 11. Print the Pyramid of numbers using for loops.
    public static void triangle2(int num) {
        int k = num - 1;
        int a = 0;

        for (int i = 0; i < num; i++) {
            for (int j = 0; j < k; j++) {
                System.out.print(" ");
            }
            k = k - 1;
            for (int j = 0; j < i + 1; j++) {
                a += 1;
                System.out.print(a + " ");
            }
            System.out.println();
        }
    }

    // 12. Write a program that will read a float type value from the keyboard and print the following output.
    //      1) the smallest integer which is not less than the number
    //      2) given number
    //      3) the largest integer which is not greater than the number
    public static void readFloatTypeNum(float f) {
        System.out.println("1. the smallest integer which is not less than the number: " + ((int) f + 1));
        System.out.println("2. given number: " + f);
        System.out.println("3. the largest integer which is not greater than the number: " + (int) f);
    }

    // 13. Choose the random number from the array.
    public static int randomNumber(int[] arr) {
        Random random = new Random();
        return arr[random.nextInt(arr.length)];
    }

    // 14. Write a function that takes an input parameter as a String.
    //     The function should replace the space in it with “%@” and print it.
    public static void replaceSpace(String s) {
        String[] arr = s.split(" ");
        StringBuilder ans = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            ans.append(arr[i]);
            if (i != arr.length - 1)
                ans.append("%@");
        }

        System.out.println(ans);
    }

    // 15. You have given a 2 sorted array. You have to merge that array into a single sorted
    //     array in O(1) space complexity.
    public static int[] mergeArrays(int[] arr1, int[] arr2, int n1, int n2) {
        int[] arr3 = new int[n1+n2];

        int i=0,j=0,k=0;

        while(i<n1 && j < n2){
            if(arr1[i] < arr2[j]){
                arr3[k] = arr1[i];
                k = k+1;
                i = i+1;
            }
            else {
                arr3[k] = arr2[j];
                k=k+1;
                j = j+1;
            }
        }

        while(i<n1){
            arr3[k] = arr1[i];
            k = k+1;
            i = i+1;
        }

        while(j < n2) {
            arr3[k] = arr2[j];
            k = k+1;
            j = j+1;
        }

        return arr3;

    }

    public static void mergeTwoArrays(int[] arr1, int[] arr2) {

            int i = 0;
            int j = 0;
            int k = arr1.length-1;

            while(i <= k && j < arr2.length){

                if(arr1[i] < arr2[j]){
                    i++;
                }else{
                    int temp = arr1[k];
                    arr1[k] = arr2[j];
                    arr2[j] = temp;
                    j++;
                    k--;
                }

            }

            // In case any element is left in arr2
            while(j < arr2.length){
                arr1[k] = arr2[j];
                j++; k--;
            }

        System.out.println(Arrays.toString(arr1));

    }

    // 16. Anagram Check
    public static boolean anagramCheck(String s1, String s2){
        s1 = s1.replace(" ","");
        s2 = s2.replace(" ","");

        char[] temp1 = s1.toCharArray();
        char[] temp2 = s2.toCharArray();
        Arrays.sort(temp1);
        Arrays.sort(temp2);
        String s3 = new String(temp1);
        String s4 = new String(temp2);

        return s3.equalsIgnoreCase(s4);
    }

}
