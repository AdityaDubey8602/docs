package practice;

import java.util.*;

public class UnionIntersection {
    public static void main(String[] args) {
        int[] arr1 = {1, 3, 4, 5, 7};
        int[] arr2 = {2, 3, 5, 6};
        unionIntersection(arr1, arr2);
    }

    public static void unionIntersection(int[] arr1, int[] arr2) {

        Map<Integer, Integer> map = new HashMap<>();

        List<Integer> union = new ArrayList<>();
        List<Integer> intersection = new ArrayList<>();

        for (int i = 0; i < arr1.length; i++) {
            if (map.containsKey(arr1[i])) {
                map.put(arr1[i], map.get(arr1[i]) + 1);
            } else {
                map.put(arr1[i], 1);
            }
        }

        for (int i = 0; i < arr2.length; i++) {
            if (map.containsKey(arr2[i])) {
                map.put(arr2[i], map.get(arr2[i]) + 1);
            } else {
                map.put(arr2[i], 1);
            }
        }

        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            union.add(entry.getKey());
        }

        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            if (entry.getValue() > 1) {
                intersection.add(entry.getKey());
            }
        }

        System.out.println("Union - " + union + "\n" + "Intersection - " + intersection);
    }

}
