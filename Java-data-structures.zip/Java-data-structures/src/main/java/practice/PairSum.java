package practice;

import java.net.Inet4Address;
import java.util.HashMap;
import java.util.Map;

public class PairSum {
    public static void main(String[] args) {
        int[] arr = {1, 1, 1, 1};
        System.out.println(getPairs(arr, 2));
    }

    // Time - O(n) & Space - O(n)
    public static int getPairs(int[] arr, int sum) {
        Map<Integer, Integer> map = new HashMap<>();
        int ans = 0;

        for (int j : arr) {
            int b = sum - j;
            if (map.containsKey(b)) {
                ans += map.get(b);
            }
            if (map.containsKey(j)) {
                map.put(j, map.get(j) + 1);
            } else {
                map.put(j, 1);
            }
        }

        return ans;
    }
}
