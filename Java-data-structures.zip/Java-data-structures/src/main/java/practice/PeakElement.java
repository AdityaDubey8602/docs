package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// https://www.geeksforgeeks.org/find-a-peak-in-a-given-array/
public class PeakElement {
    public static void main(String[] args) {
        int[] arr = {30, 10, 20, 15, 2, 23, 90, 67, 110};
        System.out.println(peakElements(arr));
        System.out.println(Arrays.toString(peakElementsReturningArray(arr)));
    }


    // When you have to return a list
    public static List<Integer> peakElements(int[] arr) {
        List<Integer> ans = new ArrayList<>();
        for (int i = 1; i < arr.length; i++) {
            if (i == arr.length - 1 && arr[i] > arr[i - 1])
                ans.add(arr[i]);
            else if (i - 1 == 0 && arr[i - 1] > arr[i])
                ans.add(arr[i - 1]);
            else if (i + 1 != arr.length && (arr[i - 1] < arr[i] && arr[i + 1] < arr[i]))
                ans.add(arr[i]);
        }
        return ans;
    }

    // When you have to return an array
    public static int[] peakElementsReturningArray(int[] arr) {
        List<Integer> list = new ArrayList<>();

        for (int i = 1; i < arr.length; i++) {
            if (i == arr.length - 1 && arr[i] > arr[i - 1])
                list.add(arr[i]);
            else if (i - 1 == 0 && arr[i - 1] > arr[i])
                list.add(arr[i - 1]);
            else if (i + 1 != arr.length && (arr[i - 1] < arr[i] && arr[i + 1] < arr[i]))
                list.add(arr[i]);
        }
        int[] ans = new int[list.size()];

        for (int i = 0; i < ans.length; i++) {
            ans[i] = list.get(i);
        }

        return ans;
    }

}
