package practice;

public class SubarrayWithGivenSum {
    public static void main(String[] args) {
        int[] arr = {1, 4, 0, 0, 3, 10, 5};
        int sum = 7;
        subarray(arr, sum);
        subArray2(arr, sum);
    }

    public static void subarray(int[] arr, int sum) {
        for (int i = 0; i < arr.length; i++) {
            int currentSum = arr[i];
            if (currentSum == sum) {
                System.out.println("Sum found at index " + i);
                return;
            } else {
                for (int j = i + 1; j < arr.length; j++) {
                    currentSum += arr[j];
                    if (currentSum == sum) {
                        System.out.println("Sum lies in bw indices " + i + " " + j);
                        return;
                    }
                }
            }
        }
        System.out.println("No subarray found");
    }


    public static void subArray2(int[] arr, int sum) {
        int currentSum = arr[0];
        int start = 0;

        for (int i = 1; i <= arr.length; i++) {

            while (currentSum > sum && start < i - 1) {
                currentSum -= arr[start];
                start++;
            }

            if (currentSum == sum) {
                int p = i - 1;
                System.out.println("Subarray found in between indices " + start + " and " + p);
                return;
            }

            if (i < arr.length) {
                currentSum += arr[i];
            }
        }

        System.out.println("No Subarray found.");

    }
}
