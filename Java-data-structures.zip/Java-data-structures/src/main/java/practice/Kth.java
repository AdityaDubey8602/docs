package practice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Kth {

    public static void main(String[] args) {
        Integer[] arr = {1, 63, 3, 2, 57, 7};
        System.out.println(kthSmOrLg(arr, 1, false));
    }

    public static int kthSmOrLg(Integer[] arr, int k, boolean small) {
        int element = 0;
        List<Integer> list;
        if (small) {
            list = Arrays.stream(arr).sorted().skip(k).toList();
        } else {
            list = Arrays.stream(arr).sorted(Comparator.reverseOrder()).skip(k).toList();
        }
        element = list.get(0);
        return element;
    }

}
