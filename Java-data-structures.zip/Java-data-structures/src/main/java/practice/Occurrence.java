package practice;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class Occurrence {
    public static void main(String[] args) {
        int arr[] = {1, 1, 2, 2, 2, 2, 3};
        System.out.println(countOccurrence(arr, 2));
    }

    public static int countOccurrence(int[] arr, int x) {

        Map<Integer, Long> map = Arrays.stream(arr).boxed().collect(Collectors.groupingBy(i -> i, Collectors.counting()));
        return Integer.parseInt(String.valueOf(map.get(x)));

    }
}
