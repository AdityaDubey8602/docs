package com.aditya.corejava;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Queue;

public class WorkingWithQueues {
    public static void main(String[] args) {

        LinkedList<Person> linkedList = new LinkedList<>();

        linkedList.add(new Person("Aditya", 22));
        linkedList.add(new Person("Shreya", 22));
        linkedList.addFirst(new Person("Akshita", 22));

        ListIterator<Person> personListIterator = linkedList.listIterator();
        while (personListIterator.hasNext()) {
            System.out.println(personListIterator.next());
        }
        System.out.println();
        while (personListIterator.hasPrevious()) {
            System.out.println(personListIterator.previous());
        }

    }

    private static void queues() {
        Queue<Person> queue = new LinkedList<>();

        queue.add(new Person("Aditya", 22));
        queue.add(new Person("Shreya", 22));
        queue.add(new Person("Deepak", 22));

        System.out.println(queue.size());
        System.out.println(queue.peek());
        System.out.println(queue.poll());
        System.out.println(queue.size());
        System.out.println(queue.peek());
    }

    static record Person(String name, int age) {}
}
