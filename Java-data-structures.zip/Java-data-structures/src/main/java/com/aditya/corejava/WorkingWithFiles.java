package com.aditya.corejava;
import java.nio.file.*;
public class WorkingWithFiles {

    public static void main(String[] args) {

        Path firstPath = Paths.get("\\home\\ashwini_ningudne\\Sarvatra\\switch-ux-web");

        System.out.println(Files.exists(firstPath));

    }


}
