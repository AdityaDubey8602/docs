package com.aditya.corejava;

import java.util.Arrays;

public class TheArrays {

    public static void main(String[] args) {
        String[] colors = new String[5];
        colors[1] = "purple";
        colors[0] = "blue";

//        System.out.println(Arrays.toString(colors));
//        System.out.println(colors[0]);
//        System.out.println(colors[1]);
//        System.out.println(colors[2]);
//        System.out.println(colors[3]);
//        System.out.println(colors[4]);

        colors[2] = "yellow";

//        System.out.println(Arrays.toString(colors));

        int[] numbers = {100, 200};

        for (int i = 0; i < colors.length; i++) {
            System.out.print(colors[i] + " ");
        }
            System.out.println();

        for (int i = colors.length-1; i >= 0  ; i--) {
            System.out.print(colors[i] + " ");
        }
        System.out.println();

        for(String color : colors) {
            System.out.print(color + " ");
        }
        System.out.println();

//        Arrays.stream(colors).forEach(x -> System.out.println(x));
            Arrays.stream(colors).forEach(x -> System.out.print(x + " "));
    }

}
