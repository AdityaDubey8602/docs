package com.aditya.corejava;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class WorkingWith2DArrays {
    public static void main(String[] args) {
//        char[][] board = new char[3][3];
//
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
//                board[i][j] = '-';
//            }
//        }
//
//        char[][] boardtwo = new char[][]{
//                new char[]{'O', '-', '-'},
//                new char[]{'O', '-', '-'},
//                new char[]{'O', '-', '-'}
//        };
//
//        board[0][0] = 'O';
//        board[1][0] = 'O';
//        board[2][0] = 'O';
//
//        System.out.println(Arrays.deepToString(boardtwo));

        int arr1[] = {1, 1, 2, 2, 3, 3, 4, 5};
        printZeroOnDuplicateValues(arr1);

    }

    public static void printZeroOnDuplicateValues(int arr[]) {

        Set<Integer> foundNumbers = new HashSet<>();

        for (int i = 0; i < arr.length; i++) {
            if (foundNumbers.contains(arr[i])) {
                arr[i] = 0;
            } else {
                foundNumbers.add(arr[i]);
            }
        }

        for (int a : arr) {
            System.out.print(a + " ");
        }

    }


}


