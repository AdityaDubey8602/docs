package core.collections;

import java.util.List;
import java.util.Vector;


// Vector is synchronized means it can access only one thread at a time
// That's why we use ArrayList because it is much faster
public class VectorExample {

    public static void main(String[] args) {

        List<Integer> vector = new Vector<>();

        vector.add(45);
        vector.add(15);
        vector.add(55);
        vector.add(25);

        System.out.println(vector);
    }

}
