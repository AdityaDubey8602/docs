package core;

import core.enumExamples.A;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class WithoutString {

    public static void main(String[] args) {

        int ans = withoutString2();
        System.out.println(ans);
//
//        String s = "Hello Java Hello";
//        wordsRepeated(s);

//        List<Integer> list = new ArrayList<>();
//
//        for (int i = 0; i <= 10; i++) {
//            list.add(i);
//        }
//
//        secondLargest(list);

    }

    public static int withoutString() {
        int a = 23456;
        int b = 34;
        int lenOfA = (int) Math.log10(a) + 1;
        // output should be 215

        int ans = 0;
        int modOfB = b % 10;
        b /= 10;
        int j = 0;

        for (int i = 1; i <= lenOfA; i++) {
            int modOfA = a % 10;
            a /= 10;
            if (modOfA == modOfB) {
                modOfB = b % 10;
                b /= 10;
            } else {
                ans += Math.pow(10, j) * modOfA;
                j++;
            }
        }

        return ans;
    }

    public static void wordsRepeated(String str) {
//        Map<String, Long> repeatedWords = Arrays.asList(str.split(" ")).stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        Map<String, Long> repeatedWords = Arrays.stream(str.split(" ")).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(repeatedWords);
    }

    public static void secondLargest(List<Integer> list) {
//        List<Integer> l1 = list.stream().sorted(Comparator.reverseOrder()).filter(n -> n%2!=0).skip(1).collect(Collectors.toList());

        List<Integer> l1 = list.stream().sorted(Comparator.reverseOrder()).filter(n -> n % 2 != 0).skip(1).collect(Collectors.toList());

        System.out.println(l1.get(0));
    }

    public static int withoutString2() {
        int a = 23415;
        int b = 34;
        int len = (int) Math.log10(a) + 1;
        int ans = 0;

        int modOfB = b % 10;
        b /= 10;
        int j = 0;

        for (int i = 1; i <= len; i++) {
            int modOfA = a % 10;
            a /= 10;
            if (modOfA == modOfB) {
                modOfB = b % 10;
                b /= 10;
            } else {
                ans += Math.pow(10, j) * modOfA;
                j++;
            }
        }

        return ans;
    }

}
