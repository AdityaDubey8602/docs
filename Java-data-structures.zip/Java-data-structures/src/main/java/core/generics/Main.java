package core.generics;

public class Main implements GenericInterface<String> {
    @Override
    public void display(String value) {
        System.out.println(value);
    }

    public static void main(String[] args) {
        Main m = new Main();
        m.display("Aditya is a good programmer.");
    }
}
