package core.generics;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.function.Consumer;

public class LambdaFunctions {

    public static void main(String[] args) {

        ArrayList<Integer> list = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            list.add(i + 1);
        }

        Consumer<Integer> fun = item -> System.out.print(item * 2 + " ");

        list.forEach(fun);

        System.out.println();

        Operation sum = (a, b) -> a + b;
        Operation product = (a, b) -> a * b;
        Operation subtraction = (a, b) -> a - b;
        Operation division = (a, b) -> a / b;

        LambdaFunctions myCalculator = new LambdaFunctions();

        System.out.println(myCalculator.operate(5, 4, sum));
        System.out.println(myCalculator.operate(5, 4, product));
        System.out.println(myCalculator.operate(5, 4, subtraction));
        System.out.println(myCalculator.operate(5, 4, division));

    }

    private int operate(int a, int b, Operation op) {
        return op.operation(a, b);
    }

}

interface Operation {
    int operation(int a, int b);
}
