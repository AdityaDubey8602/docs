package core.generics.comparing;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Student aditya = new Student(12, 89.67f);
        Student rahul = new Student(24, 85.37f);
        Student arpit = new Student(25, 56.37f);
        Student karan = new Student(13, 89.37f);
        Student sachin = new Student(15, 99.37f);

        Student[] list = {aditya, rahul, arpit, karan, sachin};

        System.out.println(Arrays.toString(list));

        Arrays.sort(list);

        System.out.println(Arrays.toString(list));

        if (aditya.compareTo(rahul) < 0) {
            System.out.println("Aditya has more marks.");
        }

    }
}
