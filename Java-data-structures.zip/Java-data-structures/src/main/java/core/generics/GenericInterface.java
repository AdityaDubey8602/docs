package core.generics;

public interface GenericInterface<T> {
    void display(T value);
}
