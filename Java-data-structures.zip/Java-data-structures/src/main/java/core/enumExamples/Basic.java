package core.enumExamples;

public class Basic {

    // We can implement interfaces but can not have subclasses or make enum as a super class
    enum Week implements A {
        Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday;
        // These are enum constants
        // Every single member here is public, static & final member
        // Since its final you can't create child enums
        // Type is Week


        Week() {
            System.out.println("Constructor initialized for : " + this);
        }

        @Override
        public void hello() {
            System.out.println("Hello");
        }
        // This is not public or protected, only private or default
        // Why? We don't want to create new objects
        // Because this is not an enum concept, that's why.

        // Internally: public static final Week Monday = new Week();

    }

    public static void main(String[] args) {

        Week week;

        week = Week.Sunday;

        week.hello();

        System.out.println(Week.valueOf("Monday"));

//        for (Week day: Week.values()){
//            System.out.print(day + " ");
//        }
//        System.out.println();
//        System.out.println(week.ordinal());

    }

}
