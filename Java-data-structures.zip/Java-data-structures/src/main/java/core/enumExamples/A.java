package core.enumExamples;

public interface A {
    void hello();
}
