package core.state;

public class StopState implements State {
    @Override
    public void doSomething(Context context) {
        System.out.println("Player is in Stop State");
        context.setState(this);
    }

    @Override
    public String toString() {
        return "Stop State";
    }
}
