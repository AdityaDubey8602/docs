package core.state;

public interface State {

    void doSomething(Context context);

}
