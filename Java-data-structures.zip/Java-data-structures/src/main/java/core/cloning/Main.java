package core.cloning;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        Human aditya = new Human(23, "Aditya Dubey");
        // Human twin = new Human(aditya);

        Human twin = (Human) aditya.clone();

        System.out.println(twin.age);
        System.out.println(twin.name);


    }
}
