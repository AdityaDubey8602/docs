package core.factory;

public class FactoryMain {
    public static void main(String[] args) {
        FactoryDesign main = new FactoryDesign();
        OS obj = main.operatingSystem("Android");
        obj.show();
    }
}
