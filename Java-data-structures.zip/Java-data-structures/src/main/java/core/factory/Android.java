package core.factory;

public class Android implements OS{

    @Override
    public void show() {
        System.out.println("This is android");
    }
}
