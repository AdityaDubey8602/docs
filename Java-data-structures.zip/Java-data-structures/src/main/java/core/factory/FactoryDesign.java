package core.factory;

public class FactoryDesign {
    public OS operatingSystem(String str) {
        if (str.equals("Android")) {
            return new Android();
        } else if (str.equals("IOS")) {
            return new Ios();
        } else {
            return new Windows();
        }
    }
}
