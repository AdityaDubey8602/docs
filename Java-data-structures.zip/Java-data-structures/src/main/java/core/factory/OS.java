package core.factory;

public interface OS {
    void show();
}
