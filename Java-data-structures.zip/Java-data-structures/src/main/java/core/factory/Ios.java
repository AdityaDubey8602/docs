package core.factory;

public class Ios implements OS{

    @Override
    public void show() {
        System.out.println("This is ios");
    }
}
