package core.factory;

public class Windows implements OS{

    @Override
    public void show() {
        System.out.println("This is windows");
    }
}
