package competitive.backtracking;

import java.util.ArrayList;

public class Maze {
    public static void main(String[] args) {
//        System.out.println(countWays(3,3));
//        waysToReachAPoint("", 3, 3);
//        System.out.println(waysToReachAPointRet("", 3, 3));

        boolean[][] maze = {
                {true, true, true},
                {true, false, true},
                {true, true, true},
        };

        waysToReachAPointRestrictions("", maze, 0, 0);

    }

    static int countWays(int row, int col) {
        if (row == 1 || col == 1) {
            return 1;
        }

        int left = countWays(row - 1, col);
        int right = countWays(row, col - 1);

        return left + right;
    }

    static void waysToReachAPoint(String processed, int row, int col) {
        if (row == 1 && col == 1) {
            System.out.print(processed + " ");
            return;
        }

        if (row > 1)
            waysToReachAPoint(processed + 'D', row - 1, col);

        if (col > 1)
            waysToReachAPoint(processed + 'R', row, col - 1);

    }

    static ArrayList<String> waysToReachAPointRet(String processed, int row, int col) {
        if (row == 1 && col == 1) {
            ArrayList<String> list = new ArrayList<>();
            list.add(processed);
            return list;
        }

        ArrayList<String> ans = new ArrayList<>();

        if (row > 1)
            ans.addAll(waysToReachAPointRet(processed + 'D', row - 1, col));

        if (col > 1)
            ans.addAll(waysToReachAPointRet(processed + 'R', row, col - 1));

        return ans;
    }

    static void waysToReachAPointDiagonally(String processed, int row, int col) {
        if (row == 1 && col == 1) {
            System.out.print(processed + " ");
            return;
        }

        if (row > 1 && col > 1)
            waysToReachAPoint(processed + "D", row - 1, col - 1);

        if (row > 1)
            waysToReachAPoint(processed + 'V', row - 1, col);

        if (col > 1)
            waysToReachAPoint(processed + 'H', row, col - 1);

    }

    static ArrayList<String> waysToReachAPointRetDiagonally(String processed, int row, int col) {
        if (row == 1 && col == 1) {
            ArrayList<String> list = new ArrayList<>();
            list.add(processed);
            return list;
        }

        ArrayList<String> ans = new ArrayList<>();

        if (row > 1 && col > 1)
            ans.addAll(waysToReachAPointRet(processed + "D", row - 1, col - 1));

        if (row > 1)
            ans.addAll(waysToReachAPointRet(processed + 'V', row - 1, col));

        if (col > 1)
            ans.addAll(waysToReachAPointRet(processed + 'H', row, col - 1));

        return ans;
    }

    static void waysToReachAPointRestrictions(String processed, boolean[][] maze, int row, int col) {
        if (row == maze.length - 1 && col == maze[0].length - 1) {
            System.out.print(processed + " ");
            return;
        }

        if (!maze[row][col])
            return;

        if (row < maze.length - 1)
            waysToReachAPointRestrictions(processed + 'D', maze, row + 1, col);

        if (col < maze[0].length - 1)
            waysToReachAPointRestrictions(processed + 'R', maze, row, col + 1);

    }

}
