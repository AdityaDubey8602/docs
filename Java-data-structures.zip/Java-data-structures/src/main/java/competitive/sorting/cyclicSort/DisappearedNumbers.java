package competitive.sorting.cyclicSort;

import java.util.ArrayList;
import java.util.List;

// Tip 1: if range is [1,N] then correctIndex is arr[i] - 1
// Tip 2: if range is [0,N] then correctIndex is arr[i]

public class DisappearedNumbers {
    public static void main(String[] args) {
        int[] arr = {4, 3, 2, 7, 8, 2, 3, 1};
        System.out.println(disappearedNumbers(arr));
    }

    static List<Integer> disappearedNumbers(int[] arr) {
        int i = 0;
        List<Integer> disappearedNumbers = new ArrayList<>();
        while (i < arr.length) {
            int correctIndex = arr[i] - 1;
            if (arr[i] != arr[correctIndex]) {
                swap(arr, i, correctIndex);
            } else {
                i++;
            }
        }

        for (int index = 0; index < arr.length; index++) {
            if (arr[index] != index + 1) {
                disappearedNumbers.add(index + 1);
            }
        }

        return disappearedNumbers;
    }

    private static void swap(int[] arr, int first, int second) {
        int temp = arr[first];
        arr[first] = arr[second];
        arr[second] = temp;
    }
}
