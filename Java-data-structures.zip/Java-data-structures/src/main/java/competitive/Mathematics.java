package competitive;

public class Mathematics {
    public static void main(String[] args) {
        int fact = 12;

//        System.out.println(findTrailingZeroes(fact));

        System.out.println(isPalindrome(1441));

    }

    public static Integer findTrailingZeroes(int fact) {
        int res = 0;

        for (int i = 5; i <= fact; i = i * 5) {
            res = res + fact / i;
        }
        return res;
    }

    public static boolean isPalindrome(int n) {

        int reverse = 0;
        int temp = n;


        while(temp != 0) {
            int modulas = temp%10;
            reverse = reverse*10 + modulas ;
            temp = temp/10;
        }

        if(reverse == n) {
            return true;
        }


        return false;
    }
}
