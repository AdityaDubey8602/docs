package competitive.linkedList;

public class ListNode {
    int val;
    ListNode next;

    ListNode(){

    }

    ListNode(int x){
        val = x;
        next = null;
    }
}
