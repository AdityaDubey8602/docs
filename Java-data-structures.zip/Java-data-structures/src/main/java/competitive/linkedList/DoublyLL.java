package competitive.linkedList;

public class DoublyLL {

    private Node head;

    //Insert After particular value
    public void insertAfter(int after, int value) {
        Node prev = find(after);

        if (prev == null) {
            System.out.println("Does not exist!");
            return;
        }

        Node node = new Node(value);

        node.next = prev.next;
        prev.next = node;
        node.prev = prev;

        if (node.next != null) {
            node.next.prev = node;
        }

    }

    public Node find(int afterValue) {
        Node node = head;
        while (node != null) {
            if (node.value == afterValue) {
                return node;
            }
            node = node.next;
        }
        return null;
    }

    public void insertFirst(int value) {
        Node node = new Node(value);
        node.next = head;
        node.prev = null;
        if (head != null) {
            head.prev = node;
        }
        head = node;
    }

    public void insertLast(int value) {

        Node node = new Node(value);

        node.next = null;

        if (head == null) {
            node.prev = null;
            head = node;
            return;
        }

        Node last = head;
        while (last.next != null) {
            last = last.next;
        }

        last.next = node;
        node.prev = last;
    }

    public void display() {
        Node node = head;
        Node last = null;
        while (node != null) {
            System.out.print(node.value + " -> ");
            last = node;
            node = node.next;
        }
        System.out.println("END");

        System.out.println("Print in reverse order - ");
        while (last != null) {
            System.out.print(last.value + " -> ");
            last = last.prev;
        }

        System.out.println("START");
    }

    private class Node {
        int value;
        Node next;
        Node prev;

        public Node(int value) {
            this.value = value;
        }

        public Node(int value, Node next, Node prev) {
            this.value = value;
            this.next = next;
            this.prev = prev;
        }
    }

}
