package competitive.linkedList;

public class Main {
    public static void main(String[] args) {
        LinkedListImpl list = new LinkedListImpl();
//
        list.insertFirst(3);
        list.insertFirst(4);
        list.insertFirst(5);
        list.insertFirst(6);
        list.insertLast(9);
        list.insert(100, 3);
        list.insertLast(10);
        list.insertLast(11);

        list.display();

        list.insertRec(89,2);

        list.display();
//
//        System.out.println(list.deleteFirst());
//        list.display();
//        System.out.println(list.deleteLast());
//        list.display();
//        System.out.println(list.delete(2));
//        list.display();

//        DoublyLL list = new DoublyLL();
//        list.insertFirst(3);
//        list.insertFirst(4);
//        list.insertFirst(5);
//        list.insertFirst(6);
//        list.insertLast(8);
//        list.insertAfter(5, 15);
//        list.display();

//        CircularLL list = new CircularLL();
//
//        list.insert(23);
//        list.insert(12);
//        list.insert(15);
//        list.insert(13);
//
//        list.display();
//        list.delete(12);
//        list.display();

    }
}
