package competitive;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RepeatingCharacter {

    public static void main(String[] args) {

        int arr[] = {2, 2, 1, 5, 1, 1, 2};
        int n = arr.length;
        int k = 3;

        System.out.println(findUnique(arr, n, k));


//        UniqueNumbers2(arr, n);


//        ArrayList<Integer> ans = get2NonRepeatingNos(arr,n);

//        System.out.println("The non repeating elements are: ");
//        System.out.println(ans.get(0) + " and " + ans.get(1));


//        List<Integer> list = Arrays.asList(arr);
//
//        System.out.println(nonRepeatingCharcterForTwiceElementsInArray(list));

    }


    // Find the only non-repeating element in an array where every element repeats twice.

    public static Integer nonRepeatingCharcterForTwiceElementsInArray(List<Integer> list) {
        int res = 0;
        for (Integer i : list) {
            res = res ^ i;
        }

        return res;
    }

    /////////////////////////////////////////////////////////////////////////////////////

    // Find the two non-repeating element in an array where every element repeats twice.

    public static ArrayList<Integer> get2NonRepeatingNos(int nums[], int n) {
        /* Time Complexity = O(nlogn) */

        Arrays.sort(nums);

        ArrayList<Integer> ans = new ArrayList<>();
        for (int i = 0; i < n - 1; i += 2) {
            if (nums[i] != nums[i + 1]) {
                ans.add(nums[i]);
                i = i - 1;
            }
        }

        if (ans.size() == 1) {
            ans.add(nums[n - 1]);
        }

        return ans;
    }

    public static void UniqueNumbers2(int[] arr, int n) {

        // Time Complexity = O(n) space = O(1)

        int sum = 0;

        for (int i = 0; i < n; i++) {
            sum = (sum ^ arr[i]);
        }

        // For Finding Rightmost bit
        sum = (sum & -sum);

        int sum1 = 0;
        int sum2 = 0;

        for (int i = 0; i < arr.length; i++) {
            if ((arr[i] & sum) > 0) {
                //one rightmost bit
                sum1 = sum1 ^ arr[i];
            } else {
                //zero rightmost bit
                sum2 = sum2 ^ arr[i];
            }
        }

        System.out.println("The non repeating elements are: " + sum1 + " and " + sum2);

    }

    ///////////////////////////////////////////////////////////////////////////////////

    // Find the only non-repeating element in an array where every other element repeats thrice.

    public static int findUnique(int a[], int n, int k) {
        byte sizeof_int = 4;
        int INT_SIZE = 8 * sizeof_int;
        int count[] = new int[INT_SIZE];

        for (int i = 0; i < INT_SIZE; i++) {
            for (int j = 0; j < n; j++) {
                if ((a[j] & (1 << i)) != 0) {
                    count[i] += 1;
                }
            }
        }

        int res = 0;

        for (int i = 0; i < INT_SIZE; i++) {
            res += (count[i] % k) * (1 << i);
        }

        res = res / (n % k);

        return res;
    }


}
