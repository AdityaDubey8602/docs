package competitive.bitwiseOperators;

public class aPowerB {
    public static void main(String[] args) {
        // Time complexity = O(log(Power))
        int base = 2;
        int power = 4;

        int ans = 1;

        while (power > 0) {
            if ((power & 1) == 1) {
                ans *= base;
            }

            base *= base;
            power = power >> 1;
        }

        System.out.println(ans);

    }
}
