package competitive.bitwiseOperators;

public class NumberOfDigits {
    public static void main(String[] args) {
        System.out.println(numberOfDigits(10, 2));
    }

    static int numberOfDigits(int n, int base) {
        return (int) (Math.log(n) / Math.log(base)) + 1;
    }
}
