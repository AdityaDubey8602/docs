package competitive.bitwiseOperators;

public class findNonRepeatedNumber {
    public static void main(String[] args) {
//        int[] arr = {1,2,3,1,2,3,4};
//        System.out.println(nonRepeatedNumber(arr));
        int a[] = {6, 2, 5, 2, 2, 6, 6};
        int k = 3;
        System.out.println(nonRepeatedNumberWithAnyNumberOfRepeatedNumbers(a, k));
    }

    // Note we can only use this method when the counting of numbers are even i.e 2, 4 etc times repeated
    static int nonRepeatedNumber(int[] arr) {
        int unique = 0;
        for (int i = 0; i < arr.length; i++) {
            unique ^= arr[i];
        }

        return unique;
    }

    // We can use this method for any number of repeated numbers
    static int nonRepeatedNumberWithAnyNumberOfRepeatedNumbers(int[] arr, int k) {
        byte sizeOfInt = 4;
        int INT_SIZE = 8 * sizeOfInt;

        int count[] = new int[INT_SIZE];

        for (int i = 0; i < INT_SIZE; i++) {
            for (int j = 0; j < arr.length; j++) {
                if ((arr[j] & (1 << i)) != 0) {
                    count[i] += 1;
                }
            }
        }

        int res = 0;

        for (int i = 0; i < INT_SIZE; i++) {
            res += (count[i] % k) * (1 << i);
        }

        res = res / (arr.length % k);

        return res;
    }
}
