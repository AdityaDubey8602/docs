package competitive.bitwiseOperators;

public class PascalTriangle {

    public static void main(String[] args) {
        int n = 3;
        System.out.println("Sum of all elements:"
                + sumOfNthRow(n));
    }

    static long sumOfNthRow(int pascalTriangleNthRow) {
        // For nth row
        long sum = 0;

        for (int row = 0; row < pascalTriangleNthRow; row++) {
            sum += (1 << row);
        }

        return sum;
    }


}
