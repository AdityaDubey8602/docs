package competitive.bitwiseOperators;

public class ithBit {
    public static void main(String[] args) {
//        int n = 0b1001101000;
//        System.out.println(findIthBit(n, 6));
//        decimalToBinary(10);

//        setIthBit(n, 4);
//        resetIthBit(n, 3);

//        System.out.println(findRightMostSetBit(n));



    }

    static int findIthBit(int number, int ithBit) {
        if ((number & (1 << ithBit - 1)) == 0) {
            return 0;
        }

        return 1;
    }



    static void setIthBit(int number, int ithBit) {
        number = number | (1 << (ithBit - 1));
        decimalToBinary(number);
    }

    static void resetIthBit(int number, int ithBit) {
        number = number & ~(1 << ithBit - 1);
        decimalToBinary(number);
    }

    static int findRightMostSetBit(int number) {
        return (int)(Math.log10(number & -number) / Math.log10(2) + 1);
    }


    static void decimalToBinary(int num) {
        int[] binary = new int[35];
        int id = 0;

        while (num > 0) {
            binary[id++] = num % 2;
            num = num / 2;
        }

        for (int i = id - 1; i >= 0; i--) {
            System.out.print(binary[i]);
        }
    }
}
