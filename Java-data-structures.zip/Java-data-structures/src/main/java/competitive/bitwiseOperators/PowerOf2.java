package competitive.bitwiseOperators;

public class PowerOf2 {
    public static void main(String[] args) {
        int n = 16; // note: fix for n = 0;

        boolean ans = (n & (n - 1)) == 0;
        if (n != 0) {
            System.out.println(ans);
        } else {
            System.out.println(false);
        }

    }
}
