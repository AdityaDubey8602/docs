package competitive.bitwiseOperators;

public class XOROfNumbersToA {
    public static void main(String[] args) {
        // range xor for a, b = xor(b) ^ xor(a-1)
        int a = 3;
        int b = 9;

        int ans = xor(b) ^ xor(a - 1);
        System.out.println(ans);
    }

    // XOR of 0 to a
    static int xor(int a) {
        // Note - for first number if a%4 = 0 then ans is a
        // if a%4 = 1 then ans is 1
        // if a%4 = 2 then ans is a+1
        // if a%4 = 3 then ans is 0


        if (a % 4 == 0) {
            return a;
        } else if (a % 4 == 1) {
            return 1;
        } else if (a % 4 == 2) {
            return a + 1;
        }


        return 0;

    }
}
