package competitive.bitwiseOperators;

public class EvenOrOdd {
    public static void main(String[] args) {
        System.out.println(isOdd(131));
    }

    static boolean isOdd(int n) {
        return (n&1) == 1;
    }
}
