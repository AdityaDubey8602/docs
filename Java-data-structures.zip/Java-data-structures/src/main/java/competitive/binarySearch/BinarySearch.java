package competitive.binarySearch;

public class BinarySearch {

    public static void main(String[] args) {

        int key = 7;

        int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int arr2[] = {9, 8, 7, 6, 5, 4, 3, 2, 1, 1};

//        System.out.println(bsRecursive(arr, key, 0, arr.length - 1));
//        System.out.println(bsIterative(arr, key, 0, arr.length - 1));

        int ans = orderAgnosticBinarySearch(arr2, 7);
        System.out.println(ans);
    }

    // Iterative Approach - a little faster than the recursive one

    public static int bsIterative(int arr[], int key, int low, int high) {

        while (low <= high) {

            int mid = (low + high) / 2;

            if (arr[mid] == key) {
                return mid;
            } else if (key > arr[mid]) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }

        }

        return -1;

    }


    // Order Agnostic Binary Search
    public static int orderAgnosticBinarySearch(int arr[], int target) {

        int start = 0;
        int end = arr.length - 1;

        // find whether array is sorted in ascending or descending order
        boolean isAscending = arr[start] < arr[end];


        while (start <= end) {
            int mid = start + (end - start) / 2;

            if (arr[mid] == target) {
                return mid;
            }

            if (isAscending) {
                if (target < arr[mid]) {
                    end = mid - 1;
                } else {
                    start = mid + 1;
                }
            } else {
                if (target > arr[mid]) {
                    end = mid - 1;
                } else {
                    start = mid + 1;
                }
            }
        }


        return -1;

    }

    // Recursive Approach

    public static int bsRecursive(int arr[], int key, int low, int high) {

        //Base check
        if (low > high)
            return -1;

        int mid = (low + high) / 2;

        if (arr[mid] == key)
            return mid;

        if (key > arr[mid])
            return bsRecursive(arr, key, mid + 1, high);

        return bsRecursive(arr, key, low, mid - 1);

    }


    // Find the element in an infinite sorted array

    public static int searchInfinite(int arr[], int key) {

        int low = 0, high = 1;

        while (arr[high] < key) {
            low = high;
            high = 2 * high;
        }

        return bsIterative(arr, key, low, high);

    }


}
