package competitive.binarySearch;

public class RotationCount {

    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5};
        // 0 = 0,1,2,4,5,6,7
        // 1 = 7,0,1,2,4,5,6
        // 2 = 6,7,0,1,2,4,5
        // 3 = 5,6,7,0,1,2,4
        // 4 = 4,5,6,7,0,1,2
        System.out.println(numberOfRotations(arr));
    }

    static int numberOfRotations(int[] arr) {
        int pivot = findPivot(arr);
        return pivot + 1;
    }


    //use this for non-duplicates
    static int findPivot(int[] arr) {
        int start = 0;
        int end = arr.length - 1;

        while (start <= end) {
            int mid = start + (end - start) / 2;

            // 4 cases over here

            // Case 1 when middle is greater than the next element
            if (mid < end && arr[mid] > arr[mid + 1]) {
                return mid;
            }
            // Case 2 when middle is smaller than the previous element
            if (mid > start && arr[mid] < arr[mid - 1]) {
                return mid - 1;
            }
            // Case 3 when middle element is less than equal to start element
            if (arr[mid] <= arr[start]) {
                end = mid - 1;
            } else {
                // Case 4 when middle element is greater than the start element
                start = mid + 1;
            }
        }

        return -1;
    }

    //use this for duplicates
    static int findPivotForDuplicateElements(int[] arr) {
        int start = 0;
        int end = arr.length - 1;

        while (start <= end) {
            int mid = start + (end - start)/2;

            // mid > next element
            if( mid < end && arr[mid] > arr[mid + 1]) {
                return mid;
            }

            // mid < previous element
            if( mid > start && arr[mid] < arr[mid - 1]) {
                return mid - 1;
            }

            // start == end == mid
            if(arr[mid] == arr[start] && arr[mid] == arr[end]){
                if(arr[start] > arr[start+1]){
                    return start;
                }
                start++;

                if(arr[end] < arr[end-1]) {
                    return end;
                }
                end--;
            }else if(arr[start] < arr[mid] || (arr[start] == arr[mid] && arr[mid] > arr[end])){
                start = mid + 1;
            }else {
                end = mid - 1;
            }
        }

        return -1;
    }

}
