package competitive.binarySearch;

public class FlippingAnImage {

    public static void main(String[] args) {

        int[][] nums = {
                {1, 1, 0, 0},
                {1, 0, 0, 1},
                {0, 1, 1, 1},
                {1, 0, 1, 0},
        };

        flippingAnImage(nums);

    }

    static void flippingAnImage(int[][] arr) {

        for (int i = 0; i < arr.length; i++) {
            reverse(arr[i]);
            invert(arr[i]);
        }

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + ",");
            }
            System.out.println();
        }

    }

    static int[] reverse(int[] nums) {
        int start = 0;
        int end = nums.length - 1;

        int temp = 0;

        while (start < end) {

            temp = nums[start];
            nums[start] = nums[end];
            nums[end] = temp;

            start++;
            end--;
        }
        return nums;
    }


    static int[] invert(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] == 0) {
                nums[i] = 1;
            } else {
                nums[i] = 0;
            }
        }
        return nums;
    }

}
