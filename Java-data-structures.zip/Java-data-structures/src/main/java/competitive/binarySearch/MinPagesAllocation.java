package competitive.binarySearch;

public class MinPagesAllocation {

    public static void main(String[] args) {

        int arr[] = {10, 5, 20};
        int k = 2;

        System.out.println(minPages(arr, k));

    }

    public static boolean isFeasible(int arr[], int k, int res) {

        int student = 1, sum = 0;

        for (int i = 0; i < arr.length; i++) {
            if (sum + arr[i] > res) {
                student++;
                sum = arr[i];
            } else {
                sum += arr[i];
            }
        }

        return student <= k;

    }

    public static int maxOf(int arr[]) {

        int max = 0;

        for (int a : arr) {
            if (a > max) {
                max = a;
            }
        }
        return max;
    }

    public static int sumOf(int arr[]) {

        int sum = 0;

        for (int a : arr) {
            sum += a;
        }
        return sum;
    }

    public static int minPages(int arr[], int k) {

        int min = maxOf(arr);
        int max = sumOf(arr);
        int res = 0;

        while (min <= max) {
            int mid = (min + max) / 2;
            if (isFeasible(arr, k, mid)) {
                res = mid;
                max = mid - 1;
            } else {
                min = mid + 1;
            }
        }

        return res;
    }


}


