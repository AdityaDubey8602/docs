package competitive;

import java.util.ArrayList;
import java.util.List;

public class ArraysQuestions {

    public static void main(String[] args) {

//        int a[] = {5, 5, 4, 5, 1};
//
//        System.out.println(majorityElement(a));

//        int a[] = {-5,-4,-2,-6,-1};
//
//        System.out.println(maxSumSubArray(a));

//        int arr[] = {3,1,4,8,7,2,5};
//
//        System.out.println(maxProfit(arr));


        int arr[] = {5,2,6,1,4,7,3,6};

        System.out.println(maxProfitForNStocks(arr)); 


    }

    // Majority element by using moore's voting algo Time complexity = O(n) and Space Complexity = O(1)
    public static int majorityElement(int arr[]) {

        int ansIndex = 0;
        int count = 1;

        for (int i = 1; i < arr.length; i++) {

            // Checking if the next element is same as the prev element
            if (arr[i] == arr[ansIndex]) {
                // If yes then increase the count
                count++;
            } else {
                // If no then decrease the count
                count--;
            }

            // After count becomes zero we assume that next element is the ans and reset the values
            if (count == 0) {
                ansIndex = i;
                count = 1;
            }

        }

        // If the ansIndex is actually the ans
        count = 0;

        for (int a : arr) {
            if (a == arr[ansIndex]) {
                count++;
            }
        }

        //Check if the count of that number is greater than N/2
        if (count > (arr.length / 2)) {
            return arr[ansIndex];
        }

        // If not greater than return -1 as false ans
        return -1;

    }

    // Max Sum of SubArray using Kadane's algo
    public static int maxSumSubArray(int arr[]) {

        int maxSum = 0;
        int curSum = 0;

        for (int i = 0; i < arr.length; i++) {
            curSum = curSum + arr[i];
            if (curSum > maxSum) {
                maxSum = curSum;
            }
            if (curSum < 0) {
                curSum = 0;
            }

        }
        return maxSum;
    }


    // Best time to buy and sell the stock to get the maximum profit * Time = O(N) Space = O(1)

    public static int maxProfit(int arr[]) {

        int maxProfit = 0;
        int minSoFar = arr[0];

        for(int i=0; i<arr.length; i++) {
            minSoFar = Math.min(minSoFar, arr[i]);
            int profit = arr[i] - minSoFar;
            maxProfit = Math.max(maxProfit, profit);
        }

        return maxProfit;
    }

    // Best time to buy and sell the stock to get the maximum profit for n stocks * Time = O(N) Space = O(1)

    public static int maxProfitForNStocks(int arr[]) {
        int profit = 0;

        for(int i=1; i<arr.length; i++) {
            if(arr[i] > arr[i-1]) {
                profit += (arr[i] - arr[i-1]);
            }
        }

        return profit;
    }


}
