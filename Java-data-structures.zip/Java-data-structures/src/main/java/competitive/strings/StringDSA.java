package competitive.strings;

public class StringDSA {

    public static void main(String[] args) {

        //Reverse String
//        String s = "I am Aditya Dubey";
//
//        System.out.println(reverseString(s));

        String[] input = {"geeksforgeeks", "geeks", "geek", "geezer"};
        System.out.println( "The longest Common Prefix is : " + longestCommonPrefix(input));

    }


    // Reverse String
    public static String reverseString(String s) {
        String ans="";

        String sArr[] = s.split(" ");

        for(int i=sArr.length-1; i>=0; i--) {
            ans += sArr[i] + " ";
        }

        return ans;
    }


    public static String longestCommonPrefix(String[] a) {
        int n = a.length;
        String result = a[0];

        for(int i=1;i<n;i++) {
            while(a[i].indexOf(result) != 0) {
                result = result.substring(0, result.length()-1);
                System.out.println(result);
                if(result.isEmpty()){
                    return "-1";
                }
            }
        }

        return result;

    }





}
