package competitive.strings;

// If we read from either left or right it should be the same
public class PalindromeString {
    public static void main(String[] args) {
        String s = null;
        System.out.println(palindrome(s));
    }

    static boolean palindrome(String s) {

        if (s == null || s.length() == 0) {
            return true;
        }
        s = s.toLowerCase();
        int start = 0;
        int end = s.length() - 1;

        while (start <= end) {
            if (s.charAt(start) == s.charAt(end)) {
                start++;
                end--;
            } else {
                return false;
            }
        }

        return true;
    }

}
