package competitive.hashing;

import java.util.HashSet;
import java.util.Set;

public class BasicProblems {

    public static void main(String[] args) {

//        int arr[] = {1, 5, 10, 15, 5, 4, 5};
//        System.out.println(distinctCount(arr));

        int a[] = {5,10,15,5,10};
        int b[] = {15,5,10,5,4};

//        unionOfTwoArrays(a,b);
        System.out.println(inserctionOfTwoArrays(a,b));

    }

    // Count distinct elements
    public static int distinctCount(int arr[]) {

        Set<Integer> set = new HashSet<>();

        for (int element : arr) {
            set.add(element);
        }

        return set.size();
    }

    // Union of two arrays
    public static void unionOfTwoArrays(int a[], int b[]) {

        Set<Integer> set = new HashSet<>();

        for (int x : a) {
            set.add(x);
        }

        for (int x : b) {
            set.add(x);
        }

        System.out.println(set);
    }

    // Intersection of two arrays
    public static int inserctionOfTwoArrays(int a[], int b[]) {
        Set<Integer> set = new HashSet<>();
        int count = 0;

        for (int x: a) {
            set.add(x);
        }

        for(int x : b) {
            if(set.contains(x)) {
                count++;
                set.remove(x);
            }
        }

        return count;
    }


}
