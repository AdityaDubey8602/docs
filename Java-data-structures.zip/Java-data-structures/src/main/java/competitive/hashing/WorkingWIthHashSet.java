package competitive.hashing;

import java.util.HashSet;

public class WorkingWIthHashSet {

    public static void main(String[] args) {

        HashSet<Integer> s = new HashSet<>();

        s.add(5);
        s.add(10);

        System.out.println(s);

        if(s.contains(10))
            System.out.println("Present");
        else
            System.out.println("Not Present");

        s.remove(10);
        System.out.println(s.isEmpty());
        System.out.println(s.size());
        s.clear();
    }

}
