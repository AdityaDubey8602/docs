package competitive.hashing;

import java.util.HashMap;

public class SubArraySum {

    public static void main(String[] args) {
        int arr[] = {10, 15, -5, 15, -10, 5};
        int sum = 5;

        subArraySum(arr,sum);
    }

    public static void subArraySum(int arr[], int sum) {

        int curSum = 0;
        int start = 0;
        int end = -1;
        int n = arr.length;

        HashMap<Integer, Integer> map = new HashMap<>();

        for (int i = 0; i < n; i++) {
            curSum += arr[i];

            // If the starting index is 0
            if ((curSum - sum) == 0) {
                start = 0;
                end = i;
                break;
            }

            // We are finding the required subarray's indices
            if (map.containsKey(curSum - sum)) {
                start = map.get(curSum - sum) + 1;
                end = i;
                break;
            }
            //If these both checks are not the cases we are getting then add the key value pair as a new
            map.put(curSum, i);

        }

        if (end == -1) {
            System.out.println("Not found");
        } else {
            System.out.print(start + " " + end);
        }

    }
}
