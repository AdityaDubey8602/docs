package competitive;

public class BitMasking {

    public static void main(String[] args) {
        int n = 0b100110101;

        int bit = 4;

        int a = 0b10110;
        int b = 0b11011;

//        System.out.println(findIthBit(n,bit));

        setIthBit(n,bit);

//        clearIthBit(n,bit);
//        System.out.println(
//                numberOfBitsToConvertAtoB(a, b)
//        );
    }

    public static Integer findIthBit(int number, int ithBit) {
        int mask = 1 << ithBit;
        if ((number & mask) == 0) {
            return 0;
        }
        return 1;
    }


    public static void setIthBit(int number, int ithBit) {
        int mask = 1 << ithBit;
        number = number | mask;
        decimalToBinary(number);
    }

    public static void clearIthBit(int number, int ithBit) {
        int mask = ~(1 << ithBit);
        number = number & mask;
        decimalToBinary(number);
    }
    /////////////////////////////////////////////////////////////
    //    Find number of bits to change, to convert a to b.

    public static Integer numberOfBitsToConvertAtoB(int a, int b) {
        int result = a ^ b;
        int count = 0;
        while(result > 0) {
            result = result & (result-1);
            count++;
        }
        return count;
    }


    ////////////////////////////////////////////////////////////
    public static void decimalToBinary(int num) {
        int[] binary = new int[35];
        int id = 0;

        while (num > 0) {
            binary[id++] = num % 2;
            num = num / 2;
        }

        for (int i = id - 1; i >= 0; i--) {
            System.out.print(binary[i] + "");
        }

    }

}
