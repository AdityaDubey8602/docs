package competitive;

public class Recursion {

    public static void main(String[] args) {
//        System.out.println(sum(5));
//        System.out.println(power(2,5));
//        System.out.println(countNoOfWays(3, 3));
//        System.out.println(josephusProblem(5,3));


//        String s = "a";
//        int l = 0;
//        int r = s.length()-1;
//
//        System.out.println(isPalindrome(s,l,r));

//        powerSet(s,0,"");
        String s = "abc";

        findPermutations(s);

    }




    public static int power(int a, int b) {
        if (b == 0) return 1;
        return a * power(a, b - 1);
    }

    public static int sum(int n) {

        if (n == 1) return 1;

        return n + sum(n - 1);
    }

//    Find Number of ways in n x m matrix.

    public static int countNoOfWays(int n, int m) {

        // Base Case
        if (n == 1 || m == 1) {
            return 1;
        }

        return countNoOfWays(n - 1, m) + countNoOfWays(n, m - 1);
    }


    // Josephus Problem

    public static int josephusProblem(int n, int k) {
        if(n == 1) {
            return 0;
        }

        return (josephusProblem(n-1, k) + k) % n;
    }


    // Palindrome String  * l and r = extreme positions *

    public static boolean isPalindrome(String s, int l, int r) {

        // Base Case
        if(l >= r) {
            return true;
        }

        if(s.charAt(l) != s.charAt(r)) {
            return false;
        }

        return isPalindrome(s, l+1, r-1);

    }

    // PowerSet of string * abc = {" ", a, b, c, ab, bc, ac, abc} *

    public static void powerSet(String s, int i, String cur) {

       // Base case
       if(i == s.length()) {
           System.out.print(cur + " ");
           return;
       }

       powerSet(s,i+1, (cur + s.charAt(i)));
       powerSet(s,i+1, cur);

    }

    // Print all the permutations of a given string

    public static void swap(char[] chars, int i, int j) {

        char temp = chars[i];
        chars[i] = chars[j];
        chars[j] = temp;

    }

    public static void permutations(char[] chars, int currentIndex) {

        if(currentIndex == chars.length - 1) {
            System.out.print(String.valueOf(chars) + " ");
        }

        for(int i=currentIndex; i<chars.length; i++) {
            swap(chars, currentIndex, i);
            permutations(chars, currentIndex+1);
            swap(chars, currentIndex, i);
        }

    }

    public static void findPermutations(String str) {

        if (str == null || str.length() == 0) {
            return;
        }

        permutations(str.toCharArray(),0);

    }

}
