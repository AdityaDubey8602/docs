package competitive.recursion.strings;

public class Ascii {
    public static void main(String[] args) {
        char ch = 'a';
        System.out.println(ch + 0);
    }
}
