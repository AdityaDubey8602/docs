package competitive.recursion.strings;

import java.util.ArrayList;

public class SubSeq {
    public static void main(String[] args) {
//        subSeq("", "abc");
//        subSeqAscii("", "abc");

//        ArrayList ans = subSeqReturn("", "abc");
//        System.out.println(ans);

        ArrayList ans = subSeqAsciiReturn("", "abc");
        System.out.println(ans);
    }

    static void subSeq(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            System.out.print(processed + " ");
            return;
        }

        char ch = unprocessed.charAt(0);

        subSeq(processed, unprocessed.substring(1));
        subSeq(processed + ch, unprocessed.substring(1));

    }

    static void subSeq(String processed, String unprocessed, ArrayList<String> ans) {
        if (unprocessed.isEmpty()) {
            if (!processed.isEmpty())
                ans.add(processed);
            return;
        }

        char ch = unprocessed.charAt(0);

        subSeq(processed, unprocessed.substring(1), ans);
        subSeq(processed + ch, unprocessed.substring(1), ans);

    }

    static ArrayList<String> subSeqReturn(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            ArrayList<String> list = new ArrayList<>();
            list.add(processed);

            return list;
        }

        char ch = unprocessed.charAt(0);

        ArrayList<String> left = subSeqReturn(processed + ch, unprocessed.substring(1));
        ArrayList<String> right = subSeqReturn(processed, unprocessed.substring(1));

        left.addAll(right);
        return left;

    }

    static void subSeqAscii(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            System.out.print(processed + " ");
            return;
        }

        char ch = unprocessed.charAt(0);

        subSeqAscii(processed, unprocessed.substring(1));
        subSeqAscii(processed + ch, unprocessed.substring(1));
        subSeqAscii(processed + (ch + 0), unprocessed.substring(1));

    }

    static ArrayList<String> subSeqAsciiReturn(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            ArrayList<String> list = new ArrayList<>();
            list.add(processed);

            return list;
        }

        char ch = unprocessed.charAt(0);

        ArrayList<String> first = subSeqAsciiReturn(processed + ch, unprocessed.substring(1));
        ArrayList<String> second = subSeqAsciiReturn(processed, unprocessed.substring(1));
        ArrayList<String> third = subSeqAsciiReturn(processed + (ch + 0), unprocessed.substring(1));

        first.addAll(second);
        first.addAll(third);
        return first;

    }


}
