package competitive.recursion.strings;

import java.util.ArrayList;

public class PhonePad {
    public static void main(String[] args) {
//        pad("", "1");
        System.out.println(padCount("", "1"));
//        System.out.println(padArrayList("", "12"));
    }

    static void pad(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            System.out.println(processed);
            return;
        }

        int digit = unprocessed.charAt(0) - '0'; // this will convert '2' into 2

        for (int i = (digit - 1) * 3; i < digit * 3; i++) {
            char ch = (char) ('a' + i);

            pad(processed + ch, unprocessed.substring(1));
        }

    }

    static ArrayList<String> padArrayList(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            ArrayList<String> list = new ArrayList<>();
            list.add(processed);
            return list;
        }

        int digit = unprocessed.charAt(0) - '0'; // this will convert '2' into 2

        ArrayList<String> ans = new ArrayList<>();

        for (int i = (digit - 1) * 3; i < digit * 3; i++) {
            char ch = (char) ('a' + i);

            ans.addAll(padArrayList(processed + ch, unprocessed.substring(1)));
        }

        return ans;
    }

    static int padCount(String processed, String unprocessed) {
        if (unprocessed.isEmpty()) {
            return 1;
        }

        int digit = unprocessed.charAt(0) - '0'; // this will convert '2' into 2
        int count = 0;
        for (int i = (digit - 1) * 3; i < digit * 3; i++) {
            char ch = (char) ('a' + i);

            count += padCount(processed + ch, unprocessed.substring(1));
        }

        return count;

    }
}
