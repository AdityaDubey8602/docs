package competitive.recursion;

public class Fibonacci {

    // Fibonacci formula = 1/root5 * ( (1 + root5/2)powerOfN -  (1 - root5/2)powerOfN )
    // Here this is ==== (1 - root5/2)powerOfN ==== less dominating term so we can remove it
    // So the formula now is = 1/root5 * (1 + root5/2)powerOfN

    public static void main(String[] args) {
//        System.out.println(fibo(6));
//        for (int i = 0; i < 11; i++) {
//            System.out.println(fiboFormula(i));
//        }
        System.out.println(fiboFormula(50));
    }


    static int fiboFormula(int n) {
//        return (int)((Math.pow(((1 + Math.sqrt(5))/2),n) - Math.pow(((1 - Math.sqrt(5))/2),n)) / Math.sqrt(5));
        return (int) (Math.pow(((1 + Math.sqrt(5)) / 2), n) / Math.sqrt(5));
    }

    static int fibo(int n) {
        if (n < 2) {
            return n;
        }
        return fibo(n - 1) + fibo(n - 2);
    }


}
