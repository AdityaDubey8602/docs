package competitive.recursion.easyProblems;

public class CountZeroes {
    public static void main(String[] args) {
        System.out.println(countZeroes(102000));
    }

    static int countZeroes(int n) {
        return helper(n, 0);
    }

    private static int helper(int n, int count) {
        int rem = n % 10;
        if (n == 0) {
            return count;
        }
        return n % 10 == 0 ? helper(n / 10, count + 1) : helper(n / 10, count);
    }
}
