package competitive.recursion.easyProblems;

public class Nto1 {
    public static void main(String[] args) {
        funBoth(5);
    }

    // Concept
    static void concept(int n) {
        if (n < 1) {
            return;
        }
        System.out.println(n);
        // It will pass n then subtract it, so it will print 5 infinite times and give error
        // concept(n--);
        // This will subtract it and then pass the value of n, so it will give us the right solution
        concept(--n);
    }

    static void fun(int n) {
        if (n < 1) {
            return;
        }
        System.out.println(n);
        fun(n - 1);
    }

    static void funRev(int n) {
        if (n < 1) {
            return;
        }
        funRev(n - 1);
        System.out.println(n);
    }

    static void funBoth(int n) {
        if (n < 1) {
            return;
        }
        System.out.println(n);
        funBoth(n - 1);
        System.out.println(n);

    }
}
