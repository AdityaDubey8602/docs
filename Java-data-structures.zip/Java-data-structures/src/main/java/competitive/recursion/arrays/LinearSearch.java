package competitive.recursion.arrays;

import java.util.ArrayList;

public class LinearSearch {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
//        System.out.println(find(arr, 0, 8));
//        System.out.println(findIndex(arr, 0, 2));
//        System.out.println(findIndexFromLast(arr, arr.length-1, 2));
        findAllIndex(arr, 0, 4);

//        ArrayList<Integer> ans = findAllIndexAndReturnList(arr, 0, 4, new ArrayList<Integer>());
//        System.out.println(ans);

//        System.out.println(list);

//        System.out.println(findAllIndexAndReturnList2(arr,0,4));
    }

    static boolean find(int[] arr, int index, int target) {
        if (index == arr.length) {
            return false;
        }

        return arr[index] == target || find(arr, index + 1, target);
    }

    static int findIndex(int[] arr, int index, int target) {
        if (index == arr.length) {
            return -1;
        }

        if (arr[index] == target) {
            return index;
        } else {
            return findIndex(arr, index + 1, target);
        }
    }

    static int findIndexFromLast(int[] arr, int index, int target) {
        if (index == -1) {
            return -1;
        }

        if (arr[index] == target) {
            return index;
        } else {
            return findIndexFromLast(arr, index - 1, target);
        }
    }

    static ArrayList<Integer> list = new ArrayList<>();

    static void findAllIndex(int[] arr, int index, int target) {
        if (index == arr.length) {
            return;
        }

        if (arr[index] == target) {
            list.add(index);
        }

        findAllIndex(arr, index + 1, target);

    }

    static ArrayList<Integer> findAllIndexAndReturnList(int[] arr, int index, int target, ArrayList<Integer> list) {
        if (index == arr.length) {
            return list;
        }

        if (arr[index] == target) {
            list.add(index);
        }

        return findAllIndexAndReturnList(arr, index + 1, target, list);

    }

//    static ArrayList<Integer> findAllIndexAndReturnList2(int[] arr, int index, int target) {
//        ArrayList<Integer> list = new ArrayList<>();
//
//        if (index == arr.length) {
//            return list;
//        }
//
//        // this will contain the ans for that function call only
//        if (arr[index] == target) {
//            list.add(index);
//        }
//
//        ArrayList<Integer> ansFromBelowCalls = findAllIndexAndReturnList2(arr, index + 1, target);
//        list.addAll(ansFromBelowCalls);
//        return list;
//    }

}
