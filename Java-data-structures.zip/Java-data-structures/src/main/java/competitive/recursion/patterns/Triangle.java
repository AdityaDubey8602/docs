package competitive.recursion.patterns;

import java.util.Arrays;

public class Triangle {
    public static void main(String[] args) {
//        triangle2(4, 0);
        int[] arr = {4, 3, 2, 1};
//        bubbleSort(arr, arr.length-1, 0);
        selectionSort(arr, arr.length, 0, 0);
        System.out.println(Arrays.toString(arr));
    }

    static void triangle2(int row, int col) {
        if (row == 0) {
            return;
        }
        if (col < row) {
            triangle2(row, col + 1);
            System.out.print("* ");
        } else {
            triangle2(row - 1, 0);
            System.out.println();
        }

    }

    static void triangle(int row, int col) {
        if (row == 0) {
            return;
        }

        if (col < row) {
            System.out.print("* ");
            triangle(row, col + 1);
        } else {
            System.out.println();
            triangle(row - 1, 0);
        }
    }

    static void bubbleSort(int[] arr, int row, int col) {
        if (row == 0) {
            return;
        }

        if (col < row) {
            if (arr[col] > arr[col + 1]) {
                swap(arr, col, col + 1);
            }
            bubbleSort(arr, row, col + 1);
        } else {
            bubbleSort(arr, row - 1, 0);
        }
    }

    static void selectionSort(int[] arr, int row, int col, int max) {
        if (row == 0) {
            return;
        }

        if (col < row) {
            if (arr[col] > arr[max]) {
                selectionSort(arr, row, col + 1, col);
            } else {
                selectionSort(arr, row, col + 1, max);
            }
        } else {
            swap(arr, max, row - 1);
            selectionSort(arr, row - 1, 0, 0);
        }
    }

    static void swap(int[] arr, int first, int second) {
        int temp = arr[first];
        arr[first] = arr[second];
        arr[second] = temp;
    }
}
