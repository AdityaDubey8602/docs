package competitive.heap;

public class Deletion {

    public static void main(String[] args) {
        int arr[] = {10, 5, 3, 2, 4};

        int n = arr.length;

        n = deleteRoot(arr, n);

        printArray(arr, n);
    }

    public static void swap(int arr[], int i, int j) {
        int temp = arr[j];
        arr[j] = arr[i];
        arr[i] = temp;
    }

    public static void heapify(int arr[], int n, int i) {

        int largest = i; // root element
        int left = 2 * i + 1; // left
        int right = 2 * i + 2; // right

        if (left < n && arr[left] > arr[largest]) {
            largest = left;
        }

        if (right < n && arr[right] > arr[largest]) {
            largest = right;
        }

        if (largest != i) {
            swap(arr, largest, i);
            heapify(arr, n, largest);
        }

    }

    public static int deleteRoot(int arr[], int n) {
        int lastElement = arr[n - 1];
        arr[0] = lastElement;

        n = n - 1;

        heapify(arr, n, 0);

        return n;
    }

    public static void printArray(int arr[], int n) {
        for (int i = 0; i < n; ++i) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }


}
