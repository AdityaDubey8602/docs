package competitive.heap;

public class CreateHeap {

    public static void main(String[] args) {

        int arr[] = {10, 30, 50, 20, 35, 15};
        int n = arr.length - 1;

        buildHeap(arr, n);
        System.out.println();
        heapSort(arr, n);

    }

    public static void swap(int arr[], int i, int j) {
        int temp = arr[j];
        arr[j] = arr[i];
        arr[i] = temp;
    }

    public static void heapify(int arr[], int n, int i) {

        int largest = i;
        int l = 2 * i;
        int r = 2 * i + 1;

        if (l <= n && arr[l] > arr[largest]) {
            largest = l;
        }

        if (r <= n && arr[r] > arr[largest]) {
            largest = r;
        }

        if (largest != i) {
            swap(arr, i, largest);
            heapify(arr, n, largest);
        }

    }

    public static void buildHeap(int arr[], int n) {
        for (int i = n / 2; i >= 0; i--) {
            heapify(arr, n, i);

        }
        for (int a : arr
        ) {
            System.out.print(a + " ");
        }
    }

    public static void heapSort(int arr[], int n) {

        for (int i = n; i >= 1; i--) {
            swap(arr, 0, i);
            heapify(arr, i - 1, 0);
        }

        for (int a : arr) {
            System.out.print(a + " ");
        }

    }

}
