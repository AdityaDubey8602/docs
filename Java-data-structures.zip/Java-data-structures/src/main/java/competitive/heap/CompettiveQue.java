package competitive.heap;

import java.util.*;

public class CompettiveQue {

    public static void main(String[] args) {

        Integer[] arr1 = {120, 100, 100, 80, 30}; // dec order
        Integer[] arr2 = {20, 40, 60, 90}; // inc order

        List<Integer> l1 = Arrays.asList(arr1);

        List<Integer> l2 = new ArrayList<>();

        List<Integer> l3 = Arrays.asList(arr2);

        l1.stream().forEach( i -> {
            if(!l2.contains(i)){
                l2.add(i);
            }
        });

        for (int i:l2) {
            System.out.print(i + " ");
        }

        System.out.println();

        int rank = 1;

        for(int i = 0; i<l3.size(); i++) {
                for (int j = 0; j < l2.size(); j++) {
                    if (l2.get(j) <= l3.get(i)) {
                        l2.set(j, l3.get(i));
                        rank = j + 1;
                        System.out.println(l3.get(i) + " : " + rank);
                        break;
                    } else if (j == l2.size()-1) {
                        l2.add(l3.get(i));
                        System.out.println(l3.get(i) + " : " + l2.size());
                        break;
                    }
                }
        }




    }

}
