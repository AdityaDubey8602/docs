package competitive.heap;

import java.util.Collections;
import java.util.PriorityQueue;

public class KthElement {

    public static void main(String[] args) {

        // For largest kth element

        int arr[] = {20, 10, 60, 30, 50, 40};
        int k = 3;

        System.out.println(kthLargest(arr, k));

        System.out.print("-------------------------------------");
        System.out.println();

        // For smallest kth element

        int arr1[] = {20, 10, 60, 30, 50, 40};
        int k1 = 3;

        System.out.println(kthSmallest(arr1, k1));

    }

    // For kth largest element we create a minHeap
    public static int kthLargest(int arr[], int k) {

        PriorityQueue<Integer> pq = new PriorityQueue<>();

        for (int i = 0; i < k; i++) {
            pq.add(arr[i]);
        }

        for (int i = k; i < arr.length; i++) {

            if (pq.peek() < arr[i]) {
                pq.poll();
                pq.add(arr[i]);
            }

        }


        return pq.peek();
    }

    // For kth smallest element we create a maxHeap
    public static int kthSmallest(int arr[], int k) {

        // It will create our maxHeap
        PriorityQueue<Integer> pq = new PriorityQueue<>(Collections.reverseOrder());

        for (int i = 0; i < k; i++) {
            pq.add(arr[i]);
        }

        for (int i = k; i < arr.length; i++) {
            if (pq.peek() > arr[i]) {
                pq.poll();
                pq.add(arr[i]);
            }
        }

        return pq.peek();

    }


}


