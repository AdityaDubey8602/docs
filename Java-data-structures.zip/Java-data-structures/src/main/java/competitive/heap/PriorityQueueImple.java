package competitive.heap;

import java.util.Collection;
import java.util.Collections;
import java.util.PriorityQueue;

public class PriorityQueueImple {

    public static void main(String[] args) {

        // It is by default creating minHeap
        PriorityQueue<Integer> pq = new PriorityQueue<>();

        pq.add(5);
        pq.add(15);
        pq.add(10);

        System.out.println(pq.size());

        while (!pq.isEmpty()) {
            System.out.println(pq.peek());
            pq.poll();
        }

        System.out.println(pq.size());

        System.out.print("-----------------------------------------------");
        System.out.println();

        // If we want pq to work for maxheap then we can do the following
        PriorityQueue<Integer> pqForMaxHeap = new PriorityQueue<>(Collections.reverseOrder());

        pqForMaxHeap.add(5);
        pqForMaxHeap.add(15);
        pqForMaxHeap.add(10);

        System.out.println(pqForMaxHeap.size());

        while (!pqForMaxHeap.isEmpty()) {
            System.out.println(pqForMaxHeap.peek());
            pqForMaxHeap.poll();
        }

        System.out.println(pqForMaxHeap.size());


    }

}
