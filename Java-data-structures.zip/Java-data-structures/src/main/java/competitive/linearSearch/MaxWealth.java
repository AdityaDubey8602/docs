package competitive.linearSearch;

public class MaxWealth {
    public static void main(String[] args) {
        int arr[][] = {
                {1,2,3},
                {2,3,4},
                {3,4,5},
        };

        System.out.println(maxWealth3(arr));
    }

    public static int maxWealth(int[][] accounts) {
        int[] wealths = new int[accounts.length];
        int sumOfWealths = 0;
        int result = 0;
        int personResult =0;
        // Person is the row and account is the column
        for (int person = 0; person < accounts.length; person++) {
            for (int account = 0; account < accounts[person].length; account++) {
                sumOfWealths += accounts[person][account];
                wealths[person] = sumOfWealths;
            }
            sumOfWealths = 0;
        }

        for (int w : wealths) {
            result = w;
            result = Math.max(result,w);
        }
        for (int i = 0; i < wealths.length; i++) {
            if(wealths[i] == result) {
                personResult = i+1;
            }
        }
        return personResult;
    }
    
    public static int maxWealth2(int[][] accounts) {
        int p = 0;
        int personWealth = 0;
        int actualPersonWealth = 0;
        for (int person = 0; person < accounts.length; person++) {
            for (int account = 0; account < accounts[person].length; account++) {
                personWealth += accounts[person][account];
            }
            if(personWealth > actualPersonWealth) {
                actualPersonWealth = personWealth;
                p = person;
            }
            personWealth = 0;
        }
        System.out.println("Wealth of " + p + " person is " + actualPersonWealth + " which is maximum.");
        return p;
    }

    public static int maxWealth3(int[][] accounts) {
        int ans = Integer.MIN_VALUE;
        for (int[] ints : accounts) {
            int sum = 0;
            for (int anInt : ints) {
                sum += anInt;
            }
            if (sum > ans) {
                ans = sum;
            }
        }
        return ans;
    }
}
