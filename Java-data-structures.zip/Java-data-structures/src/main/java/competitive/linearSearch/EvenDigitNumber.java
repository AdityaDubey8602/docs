package competitive.linearSearch;

public class EvenDigitNumber {
    public static void main(String[] args) {
//        int[] nums = {18, 1932, 6, 4, 1234};
        System.out.println(even(-9863));
        System.out.println(digits2(-9862));
    }

    static int findNumbers(int[] nums) {
        int count = 0;
        for(int n: nums) {
            if(even(n)){
                count++;
            }
        }
        return count;
    }

    static boolean even(int n) {
        if (n<0) {
            n = n * -1;
        }
        int count = 0;
        int temp = n;

        while(temp>0) {
            temp = temp/10;
            count++;
        }
        if(count%2 == 0) {
            return true;
        }
        return false;
    }

    static int digits2(int n) {
        if(n<0)
            n = n * -1;
        return (int)(Math.log10(n)) + 1;
    }

}
