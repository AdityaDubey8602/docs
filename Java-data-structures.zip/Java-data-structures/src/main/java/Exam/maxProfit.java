package Exam;

public class maxProfit {
    public static void main(String[] args) {
        int n = 1;

        int[] computerC = {1};
        int[] computerF = {3253};
        int[] computerP = {744};

        int m = 1;
        int[] orderC = {3};
        int[] orderF = {2012};
        int[] orderP = {798};

        System.out.println(maxProfit(n, computerC,computerF,computerP,m,orderC,orderF,orderP));
    }

    static int maxProfit(int n, int[] computerC, int[] computerF, int[] computerP, int m,  int[] orderC, int[] orderF, int[] orderP) {
        int requiredProfit = 0;

        if (orderC[0] > computerC[0]) {
            return requiredProfit;
        }

        return  orderP[0] - computerP[0];
    }
}
