package assignments.arrays;

import java.util.ArrayList;
import java.util.List;

// https://leetcode.com/problems/kids-with-the-greatest-number-of-candies/
public class KidWIthMaxCandies {

    public static void main(String[] args) {

        int[] candies = {2, 3, 5, 1, 3};
        System.out.println(kidsWithCandies(candies, 3));

    }

    public static List<Boolean> kidsWithCandies(int[] candies, int extraCandies) {

        int maxNoExtra = 0;

        List<Boolean> ans = new ArrayList<>();

        // getting maxNoExtra
        for (int candy : candies) {
            if (candy >= maxNoExtra) {
                maxNoExtra = candy;
            }
        }

        for (int candy : candies) {
            if ((candy + extraCandies) >= maxNoExtra) {
                ans.add(true);
            } else {
                ans.add(false);
            }
        }

        return ans;

    }
}
