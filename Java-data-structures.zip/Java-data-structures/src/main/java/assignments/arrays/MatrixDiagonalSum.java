package assignments.arrays;

//https://leetcode.com/problems/matrix-diagonal-sum/

public class MatrixDiagonalSum {

    public static void main(String[] args) {

        int[][] mat = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        System.out.println(diagonalSum(mat));

    }

    public static int diagonalSum(int[][] mat) {

        int sum = 0;
        int k = 0;

        for (int i = 0; i < mat.length; i++) {
            sum += mat[i][k];
            k++;
        }

        k--;

        for (int i = 0; i < mat.length; i++) {
            sum += mat[i][k];
            k--;
        }

        if (mat.length % 2 != 0) {
            int length = mat.length / 2;
            sum = sum - mat[length][length];
        }

        return sum;
    }

}
