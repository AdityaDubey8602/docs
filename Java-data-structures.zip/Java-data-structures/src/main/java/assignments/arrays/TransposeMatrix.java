package assignments.arrays;

// https://leetcode.com/problems/transpose-matrix/

import java.util.Arrays;

public class TransposeMatrix {

    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        int[][] ans = transpose(matrix);

        for (int[] a : ans) {
            System.out.println(Arrays.toString(a));
        }
    }

    public static int[][] transpose(int[][] matrix) {

        int[][] transMatrix = new int[matrix[0].length][matrix.length];

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                transMatrix[j][i] = matrix[i][j];
            }
        }

        return transMatrix;

    }

}
