package assignments.arrays;

// https://leetcode.com/problems/richest-customer-wealth/submissions/

public class MaxWealth {
    public static void main(String[] args) {
        int[][] arr = {
                {1, 2, 3},
                {3, 2, 1}
        };

        System.out.println(maximumWealth(arr));
    }

    public static int maximumWealth(int[][] arr) {

        int maxWealth = 0;

        for (int row = 0; row < arr.length; row++) {
            int max = 0;
            for (int col = 0; col < arr[0].length; col++) {
                max += arr[row][col];
            }
            if (max >= maxWealth) {
                maxWealth = max;
            }
        }


        return maxWealth;
    }
}


