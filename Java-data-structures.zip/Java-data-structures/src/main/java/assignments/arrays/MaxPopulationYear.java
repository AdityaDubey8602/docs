package assignments.arrays;


// https://leetcode.com/problems/maximum-population-year/
public class MaxPopulationYear {

    public static void main(String[] args) {
        int[][] logs = {
                {1950, 1961},
                {1960, 1971},
                {1970, 1981},
        };
        System.out.println(maximumPopulation(logs));
    }

    public static int maximumPopulation(int[][] logs) {
        // we have to create one counting array which is of 101 length
        // as given in constraints
        int[] arr = new int[101];

        // we will take one person's birth and death year one by one,
        // and then we will increase the count of BY and decrease the count of DY
        // in our counting array
        for (int[] log : logs) {
            // for ex. : arr = [BY, DY] = [1950, 1960] = [log[0], log[1]]
            int by = log[0];
            int dy = log[1];

            arr[by - 1950]++;
            arr[dy - 1950]--;

        }

        int max = arr[0];

        // because in constraints the starting year is 1950
        int maxYear = 1950;

        // calculate the cumulative sum
        for (int i = 1; i < arr.length; i++) {
            arr[i] += arr[i - 1];
            // we will check for maxValue that is the population
            // and the year will increase by that as well
            if (max < arr[i]) {
                max = arr[i];
                maxYear = i + maxYear;
            }
        }

        return maxYear;

    }
}
