package assignments.arrays;

// https://leetcode.com/problems/find-the-highest-altitude/

public class HighestAltitude {
    public static void main(String[] args) {

        int[] input = {-4, -3, -2, -1, 4, 3, 2};

        System.out.println(largestAltitude(input));

    }

    public static int largestAltitude(int[] gain) {
        int[] biker = new int[gain.length + 1];
        biker[0] = 0;
        // we will find the net altitudes bw i & i+1 and add it in biker's array
        for (int i = 1; i < biker.length; i++) {
            if (i == 1) {
                biker[i] = gain[0];
            } else {
                biker[i] = biker[i - 1] + gain[i - 1];
            }
        }

        // now find the max altitude from the biker's array
        int max = 0;

        for (int altitude : biker) {
            max = Math.max(max, altitude);
        }

        return max;

    }
}
