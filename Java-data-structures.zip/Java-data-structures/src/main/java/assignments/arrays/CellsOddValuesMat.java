package assignments.arrays;

// https://leetcode.com/problems/cells-with-odd-values-in-a-matrix/

public class CellsOddValuesMat {

    public static void main(String[] args) {

        int m = 2;
        int n = 2;

        int[][] indices = {
                {1, 1},
                {0, 0},
        };

        System.out.println(oddCells(m, n, indices));

    }

    public static int oddCells(int m, int n, int[][] indices) {
        int count = 0;

        int[][] matrix = new int[m][n];

        // iterate over indices and then increment the values
        for (int i = 0; i < indices.length; i++) {

            int row = indices[i][0];
            int col = indices[i][1];

            // incrementing for row
            for (int j = 0; j < n; j++) {
                matrix[row][j] += 1;
            }

            // incrementing for col
            for (int j = 0; j < m; j++) {
                matrix[j][col] += 1;
            }

        }

        for (int[] mat : matrix) {
            for (int k : mat) {
                if (k % 2 != 0) {
                    count++;
                }
            }
        }


        return count;
    }

}
