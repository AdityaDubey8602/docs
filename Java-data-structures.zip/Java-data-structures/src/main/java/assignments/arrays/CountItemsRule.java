package assignments.arrays;

// https://leetcode.com/problems/count-items-matching-a-rule/


import java.util.ArrayList;
import java.util.List;

public class CountItemsRule {

    public static void main(String[] args) {
        List<String> list1 = new ArrayList<>();
        list1.add("phone");
        list1.add("blue");
        list1.add("pixel");

        List<String> list2 = new ArrayList<>();
        list2.add("computer");
        list2.add("silver");
        list2.add("lenovo");

        List<String> list3 = new ArrayList<>();
        list3.add("phone");
        list3.add("gold");
        list3.add("iphone");

        List<List<String>> list = new ArrayList<>();
        list.add(list1);
        list.add(list2);
        list.add(list3);

        System.out.println(countMatches(list, "color", "silver"));
    }


    public static int countMatches(List<List<String>> items, String ruleKey, String ruleValue) {
        int count = 0;

        // for i = 0 : type, i = 1 : color, i = 2 : name
        int i = 0;

        if (ruleKey.equals("color")) {
            i = 1;
        } else if (ruleKey.equals("name")) {
            i = 2;
        }

        // Now create the loop that counts the items which matches the rules
        for (List<String> item : items) {
            if (item.get(i).equals(ruleValue)) {
                count++;
            }
        }

        return count;
    }

}

