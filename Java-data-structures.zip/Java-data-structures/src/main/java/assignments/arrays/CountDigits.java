package assignments.arrays;

// https://leetcode.com/problems/find-numbers-with-even-number-of-digits/

public class CountDigits {

    public static void main(String[] args) {
        int[] nums = {555, 901, 482, 1771};

        System.out.println(findNumbers(nums));
    }

    public static int findNumbers(int[] nums) {
        int count = 0;

        for (int num : nums) {
            int digits = (int) Math.log10(num) + 1;

            if (digits % 2 == 0) {
                count++;
            }

        }


        return count;
    }

}
