package assignments.arrays;

import java.util.HashSet;
import java.util.Set;

// https://leetcode.com/problems/check-if-the-sentence-is-pangram/
public class PangramCheck {
    public static void main(String[] args) {
        String sentence = "leetcode";
        System.out.println(checkIfPangram(sentence));
    }

    public static boolean checkIfPangram(String sentence) {

        if (sentence.length() < 26) {
            return false;
        }

        Set<Character> alphabets = new HashSet<>();

        for (int i = 'a'; i <= 'z'; i++) {
            alphabets.add((char) i);
        }

        for (int i = 0; i < sentence.length(); i++) {
            alphabets.remove(sentence.charAt(i));
            if (alphabets.isEmpty()) {
                return true;
            }
        }

        return false;
    }
}
