package assignments.arrays;

import java.util.Arrays;

// https://leetcode.com/problems/flipping-an-image/

public class FlippingImage {
    public static void main(String[] args) {
        int[][] mat = {
                {1, 1, 0, 0},
                {1, 0, 0, 1},
                {0, 1, 1, 1},
                {1, 0, 1, 0}
        };

        int[][] ans = flipAndInvertImage(mat);

        for (int i = 0; i < ans.length; i++) {
            System.out.println(Arrays.toString(ans[i]));
        }
    }


    public static int[][] flipAndInvertImage(int[][] image) {

        for (int[] img : image) {
            reverse(img);
            inverse(img);
        }

        return image;
    }

    public static void reverse(int[] img) {
        // For reverse, we are going to take a start and an end,
        // and then we will swap them and iterate the whole until
        // start is equal to or greater than end

        int start = 0;
        int end = img.length - 1;

        int temp = 0;

        while (start < end) {

            temp = img[start];
            img[start] = img[end];
            img[end] = temp;

            start++;
            end--;
        }

    }

    public static void inverse(int[] img) {
        // we can just use for loop to iterate and
        // convert 1 to 0 and vice versa

        for (int i = 0; i < img.length; i++) {
            if (img[i] == 0) {
                img[i] = 1;
            } else {
                img[i] = 0;
            }
        }

    }

}
