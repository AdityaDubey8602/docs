package assignments.arrays;


import java.util.Arrays;

// https://leetcode.com/problems/build-array-from-permutation/
public class ArrayFromPermutation {
    public static void main(String[] args) {
        int[] num = {0, 2, 1, 5, 3, 4};

        int[] ans = buildArray(num);

        System.out.println(Arrays.toString(ans));
    }

    public static int[] buildArray(int[] num) {
        int[] ans = new int[num.length];

        for (int i = 0; i < num.length; i++) {
            ans[i] = num[num[i]];
        }

        return ans;

    }
}
