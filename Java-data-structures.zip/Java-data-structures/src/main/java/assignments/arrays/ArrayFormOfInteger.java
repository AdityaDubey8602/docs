package assignments.arrays;


// https://leetcode.com/problems/add-to-array-form-of-integer/


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayFormOfInteger {
    public static void main(String[] args) {

        int[] arr = {2, 7, 4};

        System.out.println(addToArrayForm(arr, 181));

    }

    public static List<Integer> addToArrayForm(int[] num, int k) {

        // we have to create a list that we are going to return in the end
        List<Integer> list = new ArrayList<>();

        // we have to create one carry variable which take the extra carry that will
        // come after the addition of ith element in the array and k%10th element
        int carry = 0;

        // we now have to create a pointer to get the particular element in the array
        // which we are iterating from the last so i should be equal to that last element
        int i = num.length - 1;

        // we will iterate the array and k element until i>=0 OR k>0
        while (i >= 0 || k > 0) {

            // here we have to create one sum variable which will be the addition
            // of kth element and the carry which the particular addition gives
            int sum = carry + k % 10;

            // now after adding the kth element from here we will add the ith element
            // and also decrement ith pointer value
            if (i >= 0) {
                sum += num[i--];
            }

            // now add that last digit from sum in list by using sum % 10
            list.add(sum % 10);

            // now see if carry has something that is the remainder of sum
            // which comes when we divide sum by 10
            carry = sum / 10;

            // now also move the kth element to the other digit by dividing it with 10
            k /= 10;

        }

        // now after completing the above loop it states that we are on the i = 0 pointer or k = 0
        // if there is any carry left then we have to add it in our sum or list

        if (carry != 0) {
            list.add(carry);
        }

        // now the ans should come in reverse manner so we have to reverse it again
        Collections.reverse(list);

        // return the list
        return list;

    }

}
