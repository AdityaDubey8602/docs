package assignments.arrays;

// https://leetcode.com/problems/shuffle-the-array/

import java.util.Arrays;

public class ArrayShuffle {

    public static void main(String[] args) {
        int[] nums = {2, 5, 1, 3, 4, 7};

        int[] ans = shuffle(nums, 3);

        System.out.println(Arrays.toString(ans));
    }

    public static int[] shuffle(int[] nums, int n) {

        int[] arr = new int[nums.length];

        int count = 0;

        // for even indices
        for (int i = 0; i < arr.length; i += 2) {
            arr[i] = nums[count];
            count += 1;
        }

        // for even indices
        for (int i = 1; i < arr.length; i += 2) {
            arr[i] = nums[count];
            count += 1;
        }

        return arr;

    }
}
