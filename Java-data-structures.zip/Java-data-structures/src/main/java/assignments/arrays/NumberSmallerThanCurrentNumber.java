package assignments.arrays;

import java.util.Arrays;

// https://leetcode.com/problems/how-many-numbers-are-smaller-than-the-current-number/
// O(n) - time and O(1) - space
public class NumberSmallerThanCurrentNumber {
    public static void main(String[] args) {
        int[] nums = {6, 5, 4, 8};

        int[] ans = smallerNumbersThanCurrentOptimized(nums);

        System.out.println(Arrays.toString(ans));
    }

    // Brute force
    public static int[] smallerNumbersThanCurrent(int[] nums) {

        int[] ans = new int[nums.length];

        for (int i = 0; i < ans.length; i++) {
            int count = 0;
            for (int j = 0; j < ans.length; j++) {
                if (nums[i] > nums[j]) {
                    count++;
                }
            }
            ans[i] = count;

        }
        return ans;

    }

    // Optimal Solution

    public static int[] smallerNumbersThanCurrentOptimized(int[] nums) {

        // Create a counting array
        int[] bucket = new int[102];

        // Count the frequency
        // this will add +1 frequency for each bucket[nums[i]]
        for (int num : nums) {
            bucket[num]++;
        }

        // Now we can do the cumulative sum
        for (int i = 1; i < bucket.length; i++) {
            bucket[i] += bucket[i - 1];
        }

        // Now we can create a result array and add all the smaller numbers in it
        int[] result = new int[nums.length];

        for (int i = 0; i < result.length; i++) {
            if (nums[i] == 0) {
                result[i] = 0;
            } else {
                result[i] = bucket[nums[i] - 1];
            }
        }

        return result;

    }

}
